// Servicio de rutas: consulta OSRM, aplica fallback y actualiza datos de ruta.
;(function (global) {
  "use strict";

  function createRouteService({
    mapAdapter,
    calcularDistanciaKm,
    getOrigenCoords,
    getDestinoCoords,
    getConductorAsignado,
    getFlujoActivo,
    setRutaCalculando,
    setRutaPorCallesDisponible,
    setRutaCoords,
    setRutaInfo,
    moverCarroEnRuta,
    actualizarResumenRuta,
    actualizarPreciosPorRuta,
    mostrarEstado,
    obtenerDescripcionEstado
  }) {
    let rutaRequestId = 0;

    async function actualizarRutaReal(opciones = {}) {
      const { ajustarMapa = true, actualizarEstado = true } = opciones;
      const requestId = ++rutaRequestId;
      const origenCoords = getOrigenCoords();
      const destinoCoords = getDestinoCoords();
      const puntos = `${origenCoords[1]},${origenCoords[0]};${destinoCoords[1]},${destinoCoords[0]}`;
      const url = `https://router.project-osrm.org/route/v1/driving/${puntos}?overview=full&geometries=geojson&steps=false`;

      setRutaCalculando(true);
      setRutaPorCallesDisponible(false);

      if (actualizarEstado) {
        mostrarEstado("CalculandoRuta", "Calculando ruta real por calles...", 10);
      }

      try {
        const response = await fetch(url);

        if (!response.ok) {
          throw new Error("No se pudo consultar el servicio de rutas.");
        }

        const data = await response.json();
        const ruta = data.routes?.[0];

        if (data.code !== "Ok" || !ruta?.geometry?.coordinates?.length) {
          throw new Error("No se encontro una ruta disponible.");
        }

        if (requestId !== rutaRequestId) return;

        const rutaCoords = ruta.geometry.coordinates.map(([lng, lat]) => [lat, lng]);
        const rutaInfo = {
          distanciaKm: ruta.distance / 1000,
          duracionMin: Math.max(1, Math.round(ruta.duration / 60))
        };

        setRutaCoords(rutaCoords);
        setRutaInfo(rutaInfo);
        setRutaPorCallesDisponible(true);

        mapAdapter.setRoute(rutaCoords);
        actualizarResumenRuta();
        actualizarPreciosPorRuta();

        if (!getConductorAsignado() || !getFlujoActivo()) {
          moverCarroEnRuta(0, { animar: false });
        }

        if (ajustarMapa) {
          mapAdapter.fitRoute([84, 84]);
        }

        if (actualizarEstado) {
          mostrarEstado("TarifaCalculada", obtenerDescripcionEstado("TarifaCalculada", ""), 22);
        }
      } catch (error) {
        if (requestId !== rutaRequestId) return;

        aplicarRutaDirectaTemporal();
        mostrarEstado(
          "RutaNoDisponible",
          "No se pudo calcular una ruta por calles. Intenta con otro punto del mapa.",
          0
        );
      } finally {
        if (requestId === rutaRequestId) {
          setRutaCalculando(false);
        }
      }
    }

    function aplicarRutaDirectaTemporal() {
      const origenCoords = getOrigenCoords();
      const destinoCoords = getDestinoCoords();
      const distanciaKm = calcularDistanciaKm(origenCoords, destinoCoords);
      const rutaCoords = [origenCoords, destinoCoords];
      const rutaInfo = {
        distanciaKm,
        duracionMin: Math.max(1, Math.round((distanciaKm / 35) * 60))
      };

      setRutaCoords(rutaCoords);
      setRutaInfo(rutaInfo);
      setRutaPorCallesDisponible(false);
      mapAdapter.setRoute(rutaCoords);
      actualizarResumenRuta();
      actualizarPreciosPorRuta();

      if (!getConductorAsignado() || !getFlujoActivo()) {
        moverCarroEnRuta(0, { animar: false });
      }
    }

    return Object.freeze({
      actualizarRutaReal,
      aplicarRutaDirectaTemporal
    });
  }

  global.UberAppServices = Object.assign(global.UberAppServices || {}, {
    createRouteService
  });
})(window);
