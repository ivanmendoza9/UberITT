// Registro y ejecucion de comandos de eventos del viaje.
;(function (global) {
  "use strict";

  function createRideCommandService({
    RideCommand,
    actualizarBotonesEventos,
    puedeCancelarCliente,
    cancelarCliente,
    puedeCambiarDestino,
    cambiarDestino,
    puedeReportarEmergencia,
    emergencia,
    puedeSolicitarReembolso,
    reembolso
  }) {
    const comandosEvento = {};

    function registrarComandosEvento() {
      comandosEvento.cancelar = new RideCommand({
        puedeEjecutar: puedeCancelarCliente,
        ejecutar: cancelarCliente,
        motivoNoDisponible: "Disponible desde pedido confirmado hasta espera del cliente.",
        alNoDisponible: actualizarBotonesEventos
      });
      comandosEvento.cambiarDestino = new RideCommand({
        puedeEjecutar: puedeCambiarDestino,
        ejecutar: cambiarDestino,
        motivoNoDisponible: "Disponible cuando el viaje esta en curso.",
        alNoDisponible: actualizarBotonesEventos
      });
      comandosEvento.emergencia = new RideCommand({
        puedeEjecutar: puedeReportarEmergencia,
        ejecutar: emergencia,
        motivoNoDisponible: "Disponible desde conductor en camino hasta llegada al destino.",
        alNoDisponible: actualizarBotonesEventos
      });
      comandosEvento.reembolso = new RideCommand({
        puedeEjecutar: puedeSolicitarReembolso,
        ejecutar: reembolso,
        motivoNoDisponible: "Disponible cuando el pedido esta cerrado.",
        alNoDisponible: actualizarBotonesEventos
      });
    }

    function ejecutarComandoEvento(nombre) {
      const comando = comandosEvento[nombre];

      if (!comando) return false;

      return comando.ejecutar();
    }

    function getComando(nombre) {
      return comandosEvento[nombre];
    }

    return Object.freeze({
      registrarComandosEvento,
      ejecutarComandoEvento,
      getComando
    });
  }

  global.UberAppServices = Object.assign(global.UberAppServices || {}, {
    createRideCommandService
  });
})(window);
