// Servicio de estado: transiciones, historial, descripciones y regreso.
;(function (global) {
  "use strict";

  function createStateService({
    nombresEstado,
    estadosPrincipales,
    todosLosEstados,
    estadosRegresoDirecto = [],
    estadosReinicioObligatorio = [],
    tiposViaje,
    estadoSubject,
    estadoDescripcion,
    progressBar,
    getEstadoActual,
    setEstadoActual,
    getHistorialEstados,
    getTipoViajeSeleccionado,
    getMetodoPagoSeleccionado,
    getPagoProcesadoConfirmado,
    getCalificacionEnviada,
    calcularRangoPrecio,
    detenerFlujo,
    cerrarModalProcesarPago,
    cerrarModalCalificacion,
    onReiniciarPedido = () => {}
  }) {
    const descripcionesEstado = Object.fromEntries(todosLosEstados || estadosPrincipales);
    const estadosRegresoDirectoSet = new Set(estadosRegresoDirecto);
    const estadosReinicioObligatorioSet = new Set(estadosReinicioObligatorio);

    function mostrarEstado(estado, descripcion, progreso = null, opciones = {}) {
      const { guardarHistorial = true } = opciones;
      const estadoAnterior = getEstadoActual();
      const descripcionAnterior = estadoDescripcion.textContent;
      const progresoAnterior = progressBar.style.width;

      if (guardarHistorial && estadoAnterior && estadoAnterior !== estado) {
        getHistorialEstados().push({
          estado: estadoAnterior,
          descripcion: descripcionAnterior,
          progreso: progresoAnterior
        });
      }

      setEstadoActual(estado);
      estadoSubject.notify({
        estado,
        descripcion,
        progreso,
        estadoAnterior,
        descripcionAnterior,
        progresoAnterior
      });
    }

    function cambiarEstado(estado, descripcion, opciones = {}) {
      const indiceEstado = obtenerIndiceEstado(estado);
      const progreso = indiceEstado !== -1
        ? ((indiceEstado + 1) / estadosPrincipales.length) * 100
        : parseFloat(progressBar.style.width) || 0;

      mostrarEstado(estado, descripcion, progreso, opciones);
    }

    function formatearEstado(texto) {
      if (nombresEstado[texto]) {
        return nombresEstado[texto];
      }

      return texto.replace(/([A-Z])/g, " $1").trim();
    }

    function obtenerDescripcionEstado(estado, descripcion) {
      if (estado === "TarifaCalculada") {
        const tipoViajeSeleccionado = getTipoViajeSeleccionado();
        const tipo = tiposViaje[tipoViajeSeleccionado];
        return `${tipo.nombre} seleccionado por ${calcularRangoPrecio(tipoViajeSeleccionado)}.`;
      }

      if (estado === "MetodoPagoSeleccionado") {
        return `Metodo de pago seleccionado: ${getMetodoPagoSeleccionado()}.`;
      }

      if (estado === "PagoProcesado" && !getPagoProcesadoConfirmado()) {
        return "Confirma si deseas procesar el pago.";
      }

      if (estado === "PedidoCalificado" && !getCalificacionEnviada()) {
        return "Califica el viaje para cerrar el pedido.";
      }

      return descripcion || descripcionesEstado[estado] || "";
    }

    function obtenerIndiceEstado(estado) {
      return estadosPrincipales.findIndex(([nombre]) => nombre === estado);
    }

    function obtenerPoliticaRegreso(estado = getEstadoActual()) {
      if (estadosReinicioObligatorioSet.has(estado)) {
        return "reiniciar";
      }

      if (estadosRegresoDirectoSet.has(estado)) {
        return "anterior";
      }

      return "bloqueado";
    }

    function puedeRegresarEstado() {
      const politica = obtenerPoliticaRegreso();

      if (politica === "reiniciar") return true;
      if (politica === "anterior") return getHistorialEstados().length > 0;

      return false;
    }

    function reiniciarPedido() {
      const historialEstados = getHistorialEstados();
      historialEstados.length = 0;
      onReiniciarPedido();

      mostrarEstado(
        "PedidoIniciado",
        "Este paso no puede volver al anterior. Configura el pedido de nuevo.",
        0,
        { guardarHistorial: false }
      );
    }

    function regresarEstado() {
      const historialEstados = getHistorialEstados();
      const politica = obtenerPoliticaRegreso();

      if (politica === "bloqueado") return;

      detenerFlujo();
      cerrarModalProcesarPago();
      cerrarModalCalificacion();

      if (politica === "reiniciar") {
        reiniciarPedido();
        return;
      }

      if (!historialEstados.length) return;

      const anterior = historialEstados.pop();
      mostrarEstado(anterior.estado, anterior.descripcion, parseFloat(anterior.progreso) || 0, {
        guardarHistorial: false
      });
    }

    return Object.freeze({
      mostrarEstado,
      cambiarEstado,
      formatearEstado,
      obtenerDescripcionEstado,
      obtenerIndiceEstado,
      obtenerPoliticaRegreso,
      puedeRegresarEstado,
      regresarEstado
    });
  }

  global.UberAppServices = Object.assign(global.UberAppServices || {}, {
    createStateService
  });
})(window);
