// Servicio de conductores: flota disponible, asignacion y liberacion.
;(function (global) {
  "use strict";

  function createDriverService({
    L,
    map,
    rutasFlota,
    DriverFactory,
    obtenerPuntoEnCoordenadas,
    getOrigenCoords,
    getConductorAsignado,
    setConductorAsignado,
    setCarMarker,
    setProgresoCarro,
    setAnimacionFlotaId,
    estadoDescripcion
  }) {
    function crearIconoCarro(asignado) {
      const claseEstado = asignado ? "assigned-vehicle" : "fleet-vehicle";
      const tamano = asignado ? 46 : 36;
      const ancla = tamano / 2;

      return L.divIcon({
        className: "car-marker",
        html: `<div class="vehicle-badge ${claseEstado}"><i class="fa-solid fa-car-side" aria-hidden="true"></i></div>`,
        iconSize: [tamano, tamano],
        iconAnchor: [ancla, ancla]
      });
    }

    function crearFlotaCarros() {
      const nombres = ["Alex", "Mariana", "Luis", "Diana", "Sergio", "Nora"];

      return rutasFlota.map((ruta, index) => {
        const progresoInicial = index / rutasFlota.length;
        const marker = L.marker(obtenerPuntoEnCoordenadas(ruta, progresoInicial), {
          icon: crearIconoCarro(false),
          zIndexOffset: 250
        })
          .addTo(map)
          .bindPopup(`<b>${nombres[index]}</b><br>Conductor disponible`);

        return DriverFactory.crear({
          id: index + 1,
          nombre: nombres[index],
          ruta,
          marker,
          progreso: progresoInicial,
          velocidad: 0.000015 + index * 0.000003
        });
      });
    }

    function iniciarMovimientoFlota(flotaCarros) {
      let tiempoAnterior = performance.now();

      function moverFlota(tiempoActual) {
        const delta = tiempoActual - tiempoAnterior;
        tiempoAnterior = tiempoActual;

        flotaCarros.forEach(auto => {
          if (auto.asignado) return;

          auto.progreso = (auto.progreso + auto.velocidad * delta) % 1;
          auto.marker.setLatLng(obtenerPuntoEnCoordenadas(auto.ruta, auto.progreso));
        });

        setAnimacionFlotaId(requestAnimationFrame(moverFlota));
      }

      setAnimacionFlotaId(requestAnimationFrame(moverFlota));
    }

    function asignarConductorMasCercano(flotaCarros) {
      const conductorAsignado = getConductorAsignado();

      if (conductorAsignado) {
        anunciarConductor(conductorAsignado);
        return conductorAsignado;
      }

      const origenLatLng = L.latLng(getOrigenCoords());
      let conductorCercano = null;
      let distanciaMenor = Infinity;

      flotaCarros.forEach(auto => {
        if (auto.asignado) return;

        const distancia = auto.marker.getLatLng().distanceTo(origenLatLng);

        if (distancia < distanciaMenor) {
          distanciaMenor = distancia;
          conductorCercano = auto;
        }
      });

      if (!conductorCercano) return null;

      conductorCercano.asignado = true;
      conductorCercano.distanciaAlOrigen = distanciaMenor;
      conductorCercano.marker.setIcon(crearIconoCarro(true));
      conductorCercano.marker.setZIndexOffset(900);
      conductorCercano.marker.setPopupContent(
        `<b>${conductorCercano.nombre}</b><br>Conductor asignado`
      );

      setConductorAsignado(conductorCercano);
      setCarMarker(conductorCercano.marker);
      setProgresoCarro(0);

      anunciarConductor(conductorCercano);
      return conductorCercano;
    }

    function anunciarConductor(conductor) {
      const distanciaKm = conductor.distanciaAlOrigen / 1000;
      estadoDescripcion.textContent = `${conductor.nombre} es el conductor mas cercano, a ${distanciaKm.toFixed(1)} km del punto de partida.`;
    }

    function liberarConductorAsignado() {
      const conductorAsignado = getConductorAsignado();

      if (!conductorAsignado) {
        setCarMarker(null);
        return;
      }

      conductorAsignado.asignado = false;
      conductorAsignado.marker.setIcon(crearIconoCarro(false));
      conductorAsignado.marker.setZIndexOffset(250);
      conductorAsignado.marker.setPopupContent(
        `<b>${conductorAsignado.nombre}</b><br>Conductor disponible`
      );
      setConductorAsignado(null);
      setCarMarker(null);
    }

    return Object.freeze({
      crearFlotaCarros,
      crearIconoCarro,
      iniciarMovimientoFlota,
      asignarConductorMasCercano,
      anunciarConductor,
      liberarConductorAsignado
    });
  }

  global.UberAppServices = Object.assign(global.UberAppServices || {}, {
    createDriverService
  });
})(window);
