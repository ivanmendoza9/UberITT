// Servicio de eventos del viaje: permisos y acciones del usuario.
;(function (global) {
  "use strict";

  function createRideEventService({
    getEstadoActual,
    setRecalculoDestinoEnCurso,
    detenerFlujo,
    cambiarEstado,
    seleccionarModoMapa
  }) {
    function puedeCancelarCliente() {
      return [
        "PedidoConfirmado",
        "BuscandoConductor",
        "ConductorAsignado",
        "ConductorEnCamino",
        "ConductorLlego",
        "EsperandoCliente"
      ].includes(getEstadoActual());
    }

    function puedeCambiarDestino() {
      return getEstadoActual() === "PedidoEnCurso";
    }

    function puedeReportarEmergencia() {
      return [
        "ConductorEnCamino",
        "ConductorLlego",
        "EsperandoCliente",
        "ClienteAbordo",
        "PedidoEnCurso",
        "LlegandoDestino"
      ].includes(getEstadoActual());
    }

    function puedeSolicitarReembolso() {
      return getEstadoActual() === "PedidoCerrado";
    }

    function puedeMarcarSinConductor() {
      return getEstadoActual() === "BuscandoConductor";
    }

    function puedeExpirarPedido() {
      return getEstadoActual() === "BuscandoConductor";
    }

    function puedeCancelarPorConductor() {
      return [
        "ConductorAsignado",
        "ConductorEnCamino",
        "ConductorLlego",
        "EsperandoCliente"
      ].includes(getEstadoActual());
    }

    function puedeMarcarNoShow() {
      return getEstadoActual() === "EsperandoCliente";
    }

    function cancelarCliente() {
      if (puedeCancelarCliente()) {
        detenerFlujo();
        cambiarEstado(
          "PedidoCanceladoPorCliente",
          "El cliente cancelo el viaje."
        );
        return;
      }

      alert("No puedes cancelar el viaje en este estado.");
    }

    function cambiarDestino() {
      if (puedeCambiarDestino()) {
        setRecalculoDestinoEnCurso(true);
        seleccionarModoMapa("destino");
        cambiarEstado(
          "RecalcularTarifa",
          "Marca el nuevo destino en el mapa."
        );
        return;
      }

      alert("Solo puedes cambiar el destino cuando el viaje esta en curso.");
    }

    function emergencia() {
      if (puedeReportarEmergencia()) {
        detenerFlujo();

        cambiarEstado(
          "PedidoEnRevision",
          "El viaje quedo en revision por un incidente reportado."
        );
        return;
      }

      alert("La emergencia solo esta disponible cuando el conductor va en camino o durante el viaje.");
    }

    function reembolso() {
      if (puedeSolicitarReembolso()) {
        cambiarEstado(
          "ReembolsoEnRevision",
          "Tu solicitud de reembolso fue enviada a revision."
        );
        return;
      }

      alert("Solo puedes solicitar reembolso cuando el pedido ya esta cerrado.");
    }

    function marcarPedidoSinConductor() {
      if (!puedeMarcarSinConductor()) {
        alert("Solo aplica mientras se esta buscando conductor.");
        return;
      }

      detenerFlujo();
      cambiarEstado(
        "PedidoSinConductor",
        "No hubo conductores disponibles para aceptar el pedido."
      );
    }

    function expirarPedido() {
      if (!puedeExpirarPedido()) {
        alert("Solo aplica mientras se esta buscando conductor.");
        return;
      }

      detenerFlujo();
      cambiarEstado(
        "PedidoExpirado",
        "La busqueda se agoto antes de encontrar conductor."
      );
    }

    function cancelarPorConductor() {
      if (!puedeCancelarPorConductor()) {
        alert("El conductor solo puede cancelar antes de que el cliente aborde.");
        return;
      }

      detenerFlujo();
      cambiarEstado(
        "PedidoCanceladoPorConductor",
        "El conductor cancelo antes de iniciar o continuar la recogida."
      );
    }

    function marcarNoShow() {
      if (!puedeMarcarNoShow()) {
        alert("El no-show solo aplica cuando el conductor esta esperando al cliente.");
        return;
      }

      detenerFlujo();
      cambiarEstado(
        "PedidoCanceladoPorNoShow",
        "El cliente no se presento en el punto de recogida."
      );
    }

    return Object.freeze({
      puedeCancelarCliente,
      puedeCambiarDestino,
      puedeReportarEmergencia,
      puedeSolicitarReembolso,
      puedeMarcarSinConductor,
      puedeExpirarPedido,
      puedeCancelarPorConductor,
      puedeMarcarNoShow,
      cancelarCliente,
      cambiarDestino,
      emergencia,
      reembolso,
      marcarPedidoSinConductor,
      expirarPedido,
      cancelarPorConductor,
      marcarNoShow
    });
  }

  global.UberAppServices = Object.assign(global.UberAppServices || {}, {
    createRideEventService
  });
})(window);
