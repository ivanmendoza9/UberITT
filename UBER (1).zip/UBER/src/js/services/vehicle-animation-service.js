// Servicio de animacion del vehiculo asignado e interpolacion de rutas.
;(function (global) {
  "use strict";

  function createVehicleAnimationService({
    L,
    mapAdapter,
    limitarProgreso,
    suavizarMovimiento,
    getCarMarker,
    getAnimacionCarroId,
    setAnimacionCarroId,
    getProgresoCarro,
    setProgresoCarro,
    getRutaCoords,
    getOrigenCoords
  }) {
    let resolverAnimacionCarro = null;

    function resolverAnimacionPendiente() {
      if (!resolverAnimacionCarro) return;

      const resolver = resolverAnimacionCarro;
      resolverAnimacionCarro = null;
      resolver();
    }

    function moverCarro(coords) {
      const carMarker = getCarMarker();
      if (!carMarker) return;

      carMarker.setLatLng(coords);
    }

    function moverCarroAPunto(coordsDestino, opciones = {}) {
      const carMarker = getCarMarker();
      if (!carMarker) return Promise.resolve();

      const { animar = true, duracion = 1400, progresoFinal = null } = opciones;
      const inicio = carMarker.getLatLng();
      const destino = L.latLng(coordsDestino);
      const inicioTiempo = performance.now();

      detenerAnimacionCarro();

      if (!animar || duracion <= 0) {
        if (progresoFinal !== null) {
          setProgresoCarro(limitarProgreso(progresoFinal));
        }

        moverCarro(coordsDestino);
        return Promise.resolve();
      }

      return new Promise(resolve => {
        resolverAnimacionCarro = resolve;

        function animarPaso(tiempoActual) {
          const avance = Math.min(1, (tiempoActual - inicioTiempo) / duracion);
          const suavizado = suavizarMovimiento(avance);
          const lat = inicio.lat + (destino.lat - inicio.lat) * suavizado;
          const lng = inicio.lng + (destino.lng - inicio.lng) * suavizado;

          moverCarro([lat, lng]);

          if (avance < 1) {
            setAnimacionCarroId(requestAnimationFrame(animarPaso));
            return;
          }

          if (progresoFinal !== null) {
            setProgresoCarro(limitarProgreso(progresoFinal));
          }

          setAnimacionCarroId(null);
          moverCarro(coordsDestino);
          resolverAnimacionPendiente();
        }

        setAnimacionCarroId(requestAnimationFrame(animarPaso));
      });
    }

    function moverCarroEnRuta(progresoDestino, opciones = {}) {
      const { animar = true, duracion = 1400 } = opciones;
      const destino = limitarProgreso(progresoDestino);

      detenerAnimacionCarro();

      if (!animar || duracion <= 0) {
        setProgresoCarro(destino);
        moverCarro(obtenerPuntoRuta(destino));
        return Promise.resolve();
      }

      const inicio = getProgresoCarro();
      const inicioTiempo = performance.now();

      return new Promise(resolve => {
        resolverAnimacionCarro = resolve;

        function animarPaso(tiempoActual) {
          const avance = Math.min(1, (tiempoActual - inicioTiempo) / duracion);
          const suavizado = suavizarMovimiento(avance);
          const progresoCarro = inicio + (destino - inicio) * suavizado;
          setProgresoCarro(progresoCarro);

          moverCarro(obtenerPuntoRuta(progresoCarro));

          if (avance < 1) {
            setAnimacionCarroId(requestAnimationFrame(animarPaso));
            return;
          }

          setProgresoCarro(destino);
          setAnimacionCarroId(null);
          moverCarro(obtenerPuntoRuta(destino));
          resolverAnimacionPendiente();
        }

        setAnimacionCarroId(requestAnimationFrame(animarPaso));
      });
    }

    function detenerAnimacionCarro() {
      const animacionCarroId = getAnimacionCarroId();
      if (!animacionCarroId) {
        resolverAnimacionPendiente();
        return;
      }

      cancelAnimationFrame(animacionCarroId);
      setAnimacionCarroId(null);
      resolverAnimacionPendiente();
    }

    function obtenerPuntoRuta(progreso) {
      const rutaCoords = getRutaCoords();
      return obtenerPuntoEnCoordenadas(rutaCoords.length ? rutaCoords : [getOrigenCoords()], progreso);
    }

    function obtenerPuntoEnCoordenadas(coordenadas, progreso) {
      if (!coordenadas.length) {
        return getOrigenCoords();
      }

      if (coordenadas.length === 1) {
        return coordenadas[0];
      }

      const objetivo = calcularLongitudCoordenadas(coordenadas) * limitarProgreso(progreso);
      let recorrido = 0;

      for (let i = 0; i < coordenadas.length - 1; i++) {
        const puntoA = mapAdapter.toLayerPoint(coordenadas[i]);
        const puntoB = mapAdapter.toLayerPoint(coordenadas[i + 1]);
        const longitudSegmento = puntoA.distanceTo(puntoB);

        if (recorrido + longitudSegmento >= objetivo) {
          const restante = objetivo - recorrido;
          const proporcion = longitudSegmento === 0 ? 0 : restante / longitudSegmento;
          const puntoInterpolado = L.point(
            puntoA.x + (puntoB.x - puntoA.x) * proporcion,
            puntoA.y + (puntoB.y - puntoA.y) * proporcion
          );

          return mapAdapter.fromLayerPoint(puntoInterpolado);
        }

        recorrido += longitudSegmento;
      }

      return coordenadas[coordenadas.length - 1];
    }

    function calcularLongitudRuta() {
      return calcularLongitudCoordenadas(getRutaCoords());
    }

    function calcularLongitudCoordenadas(coordenadas) {
      let longitud = 0;

      for (let i = 0; i < coordenadas.length - 1; i++) {
        const puntoA = mapAdapter.toLayerPoint(coordenadas[i]);
        const puntoB = mapAdapter.toLayerPoint(coordenadas[i + 1]);
        longitud += puntoA.distanceTo(puntoB);
      }

      return longitud;
    }

    return Object.freeze({
      moverCarro,
      moverCarroAPunto,
      moverCarroEnRuta,
      detenerAnimacionCarro,
      obtenerPuntoRuta,
      obtenerPuntoEnCoordenadas,
      calcularLongitudRuta,
      calcularLongitudCoordenadas
    });
  }

  global.UberAppServices = Object.assign(global.UberAppServices || {}, {
    createVehicleAnimationService
  });
})(window);
