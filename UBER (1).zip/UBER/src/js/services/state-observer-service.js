// Registro de observers que reaccionan a cambios de estado.
;(function (global) {
  "use strict";

  function createStateObserverService({
    estadoSubject,
    EstadoUiObserver,
    EstadoProgresoObserver,
    EstadoFlujoObserver,
    EstadoAccionesObserver,
    estadoTitulo,
    estadoDescripcion,
    progressBar,
    formatearEstado,
    obtenerIndiceEstado,
    setIndiceFlujo,
    renderizarOpcionesEstado
  }) {
    let observadoresEstadoRegistrados = false;

    function registrarObservadoresEstado() {
      if (observadoresEstadoRegistrados) return;

      estadoSubject.subscribe(new EstadoUiObserver({
        estadoTitulo,
        estadoDescripcion,
        formatearEstado
      }));
      estadoSubject.subscribe(new EstadoProgresoObserver({
        progressBar
      }));
      estadoSubject.subscribe(new EstadoFlujoObserver({
        obtenerIndiceEstado,
        setIndiceFlujo
      }));
      estadoSubject.subscribe(new EstadoAccionesObserver({
        renderizarOpcionesEstado
      }));
      observadoresEstadoRegistrados = true;
    }

    return Object.freeze({
      registrarObservadoresEstado
    });
  }

  global.UberAppServices = Object.assign(global.UberAppServices || {}, {
    createStateObserverService
  });
})(window);
