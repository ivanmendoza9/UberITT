// Servicio de interaccion con el mapa: modo origen/destino y cambios de puntos.
;(function (global) {
  "use strict";

  function createMapInteractionService({
    mapUi,
    normalizarLatLng,
    progressBar,
    inputOrigen,
    inputDestino,
    getModoMapa,
    setModoMapa,
    getFlujoActivo,
    setIndiceFlujo,
    getRecalculoDestinoEnCurso,
    setRecalculoDestinoEnCurso,
    setOrigenCoords,
    setDestinoCoords,
    detenerFlujo,
    actualizarRutaReal,
    getRutaPorCallesDisponible,
    cambiarEstado
  }) {
    function seleccionarModoMapa(tipo) {
      const modo = mapUi.seleccionarModoMapa(tipo);
      setModoMapa(modo);
      return modo;
    }

    function actualizarPuntoMapa(tipo, latlng, opciones = {}) {
      const { cambiarModo = true } = opciones;
      const coords = normalizarLatLng(latlng);
      const mantieneViajeEnCurso = getFlujoActivo() && getRecalculoDestinoEnCurso() && tipo === "destino";

      if (getFlujoActivo() && !mantieneViajeEnCurso) {
        detenerFlujo();
      }

      if (!mantieneViajeEnCurso) {
        setIndiceFlujo(0);
        progressBar.style.width = "0%";
      }

      if (tipo === "origen") {
        setOrigenCoords(coords);
        mapUi.actualizarPuntoVisual("origen", coords);

        if (cambiarModo) {
          seleccionarModoMapa("destino");
        }
      } else {
        setDestinoCoords(coords);
        mapUi.actualizarPuntoVisual("destino", coords);
      }

      const rutaActualizada = actualizarRutaReal({
        actualizarEstado: !mantieneViajeEnCurso
      });

      if (mantieneViajeEnCurso) {
        setRecalculoDestinoEnCurso(false);

        rutaActualizada.then(() => {
          if (getRutaPorCallesDisponible()) {
            cambiarEstado(
              "PedidoEnCurso",
              "Destino actualizado. El viaje continua."
            );
          }
        });
      }

      return rutaActualizada;
    }

    function limpiarCampo(id) {
      const input = id === "origen" ? inputOrigen : inputDestino;
      input.value = "";
      seleccionarModoMapa(id === "origen" ? "origen" : "destino");
    }

    return Object.freeze({
      seleccionarModoMapa,
      actualizarPuntoMapa,
      limpiarCampo,
      getModoMapa
    });
  }

  global.UberAppServices = Object.assign(global.UberAppServices || {}, {
    createMapInteractionService
  });
})(window);
