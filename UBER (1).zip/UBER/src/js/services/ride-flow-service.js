// Servicio de flujo del viaje: avance automatico/manual y efectos por estado.
;(function (global) {
  "use strict";

  function createRideFlowService({
    estadosPrincipales,
    estadosTerminales = [],
    inputOrigen,
    inputDestino,
    estadoDescripcion,
    getFlujoActivo,
    setFlujoActivo,
    getIndiceFlujo,
    setIndiceFlujo,
    getEstadoActual,
    getRutaCalculando,
    getRutaPorCallesDisponible,
    getConductorAsignado,
    getOrigenCoords,
    setProgresoCarro,
    setPagoProcesadoConfirmado,
    setCalificacionCliente,
    setCalificacionEnviada,
    getPagoProcesadoConfirmado,
    getCalificacionEnviada,
    setIntervaloFlujo,
    cerrarMetodoPago,
    detenerAnimacionCarro,
    liberarConductorAsignado,
    cerrarModalProcesarPago,
    cerrarModalCalificacion,
    cambiarEstado,
    obtenerDescripcionEstado,
    asignarConductorMasCercano,
    moverCarroAPunto,
    moverCarroEnRuta,
    abrirModalProcesarPago,
    abrirModalCalificacion,
    obtenerIndiceEstado
  }) {
    let intervaloFlujo = null;
    let avanceEnCurso = false;
    const esperaEntreEstados = 1100;
    const estadosFinalesSet = new Set(estadosTerminales);

    function iniciarFlujo() {
      if (getFlujoActivo()) return;

      cerrarMetodoPago();

      const origen = inputOrigen.value.trim();
      const destino = inputDestino.value.trim();

      if (!origen || !destino) {
        alert("Completa el punto de partida y destino.");
        return;
      }

      if (getRutaCalculando()) {
        alert("Espera a que termine el calculo de la ruta real.");
        return;
      }

      if (!getRutaPorCallesDisponible()) {
        alert("Primero marca una ruta valida por calles.");
        return;
      }

      detenerAnimacionCarro();
      liberarConductorAsignado();
      setFlujoActivo(true);
      setIndiceFlujo(0);
      setProgresoCarro(0);
      setPagoProcesadoConfirmado(false);
      setCalificacionCliente(0);
      setCalificacionEnviada(false);
      cerrarModalProcesarPago();
      cerrarModalCalificacion();

      cambiarEstado("PedidoIniciado", "Preparando tu solicitud de viaje...");

      setIndiceFlujo(1);
      programarSiguienteAvance(esperaEntreEstados);
    }

    function programarSiguienteAvance(espera = esperaEntreEstados) {
      detenerIntervalo();
      intervaloFlujo = setTimeout(avanzarFlujoAutomatico, espera);
      setIntervaloFlujo(intervaloFlujo);
    }

    async function avanzarFlujoAutomatico() {
      if (avanceEnCurso || !getFlujoActivo()) return;

      avanceEnCurso = true;
      const indiceFlujo = getIndiceFlujo();

      if (indiceFlujo >= estadosPrincipales.length) {
        detenerIntervalo();
        setFlujoActivo(false);
        avanceEnCurso = false;
        return;
      }

      const [estado, descripcion] = estadosPrincipales[indiceFlujo];
      const descripcionEstado = obtenerDescripcionEstado(estado, descripcion);
      const estadoActual = getEstadoActual();

      if (estadosFinalesSet.has(estadoActual) || estadoActual.includes("Cancelado") || estadoActual.includes("Revision")) {
        detenerIntervalo();
        setFlujoActivo(false);
        avanceEnCurso = false;
        return;
      }

      cambiarEstado(estado, descripcionEstado);
      await moverCarroPorEstado(estado);

      if (!getFlujoActivo() || getEstadoActual() !== estado) {
        avanceEnCurso = false;
        return;
      }

      if (estado === "PagoProcesado") {
        detenerIntervalo();
        setFlujoActivo(false);
        setIndiceFlujo(getIndiceFlujo() + 1);
        abrirModalProcesarPago();
        avanceEnCurso = false;
        return;
      }

      if (estado === "PedidoCalificado") {
        detenerIntervalo();
        setFlujoActivo(false);
        setIndiceFlujo(getIndiceFlujo() + 1);
        abrirModalCalificacion();
        avanceEnCurso = false;
        return;
      }

      setIndiceFlujo(getIndiceFlujo() + 1);
      avanceEnCurso = false;
      programarSiguienteAvance();
    }

    async function avanzarEstadoManual() {
      if (avanceEnCurso) return;

      avanceEnCurso = true;
      const indiceEstado = obtenerIndiceEstado(getEstadoActual());
      const siguienteIndice = indiceEstado === -1 ? 0 : indiceEstado + 1;
      const siguiente = estadosPrincipales[siguienteIndice];

      if (!siguiente) {
        avanceEnCurso = false;
        return;
      }

      const [estado, descripcion] = siguiente;
      cambiarEstado(estado, obtenerDescripcionEstado(estado, descripcion));
      await moverCarroPorEstado(estado);

      if (getEstadoActual() !== estado) {
        avanceEnCurso = false;
        return;
      }

      if (estado === "PagoProcesado" && !getPagoProcesadoConfirmado()) {
        abrirModalProcesarPago();
      }

      if (estado === "PedidoCalificado" && !getCalificacionEnviada()) {
        abrirModalCalificacion();
      }

      avanceEnCurso = false;
    }

    function moverCarroPorEstado(estado) {
      if (estado === "BuscandoConductor") {
        asignarConductorMasCercano();
        return Promise.resolve();
      }

      if (estado === "ConductorAsignado") {
        const conductor = asignarConductorMasCercano();

        if (conductor) {
          estadoDescripcion.textContent = `${conductor.nombre} acepto tu viaje y va hacia ti.`;
        }

        return Promise.resolve();
      }

      if (estado === "ConductorEnCamino") {
        if (!getConductorAsignado()) {
          asignarConductorMasCercano();
        }

        return moverCarroAPunto(getOrigenCoords(), { duracion: 3000, progresoFinal: 0 });
      }

      if (estado === "ConductorLlego" || estado === "EsperandoCliente") {
        return moverCarroAPunto(getOrigenCoords(), { animar: false, progresoFinal: 0 });
      }

      if (estado === "ClienteAbordo") {
        return moverCarroEnRuta(0.05, { animar: false });
      }

      if (estado === "PedidoEnCurso") {
        return moverCarroEnRuta(0.58, { duracion: 3000 });
      }

      if (estado === "LlegandoDestino") {
        return moverCarroEnRuta(0.85, { duracion: 2600 });
      }

      if (estado === "DestinoAlcanzado") {
        return moverCarroEnRuta(1, { duracion: 3400 });
      }

      if (estado === "PedidoFinalizado") {
        return moverCarroEnRuta(1, { animar: false });
      }

      return Promise.resolve();
    }

    function detenerFlujo() {
      detenerIntervalo();
      avanceEnCurso = false;
      setFlujoActivo(false);
      detenerAnimacionCarro();
    }

    function detenerIntervalo() {
      if (intervaloFlujo) {
        clearTimeout(intervaloFlujo);
        intervaloFlujo = null;
      }

      setIntervaloFlujo(null);
    }

    return Object.freeze({
      iniciarFlujo,
      avanzarEstadoManual,
      moverCarroPorEstado,
      detenerFlujo,
      detenerIntervalo
    });
  }

  global.UberAppServices = Object.assign(global.UberAppServices || {}, {
    createRideFlowService
  });
})(window);
