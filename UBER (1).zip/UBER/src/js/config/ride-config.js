// Configuracion principal de la app de viajes.
;(function (global) {
  "use strict";

  const {
    RideTypeFactory,
    MetodoPagoFactory
  } = global.UberPatterns;

  const estadosPrincipales = Object.freeze([
    ["PedidoIniciado", "El cliente empieza a crear el pedido."],
    ["OrigenSeleccionado", "Punto de partida seleccionado."],
    ["DestinoSeleccionado", "Destino seleccionado."],
    ["TarifaCalculada", "Precio, distancia y tiempo estimado calculados."],
    ["MetodoPagoSeleccionado", "Metodo de pago seleccionado."],
    ["PedidoConfirmado", "El pedido fue confirmado."],
    ["BuscandoConductor", "Hay alta demanda en tu zona. Te conectaremos pronto."],
    ["ConductorAsignado", "Un conductor acepto tu pedido."],
    ["ConductorEnCamino", "Tu conductor va hacia el punto de partida."],
    ["ConductorLlego", "Tu conductor llego al punto de recogida."],
    ["EsperandoCliente", "El conductor espera que abordes el vehiculo."],
    ["ClienteAbordo", "El cliente subio al vehiculo."],
    ["PedidoEnCurso", "El viaje esta en proceso."],
    ["LlegandoDestino", "Estas cerca de tu destino."],
    ["DestinoAlcanzado", "Llegaste al destino."],
    ["PedidoFinalizado", "El conductor finalizo el viaje."],
    ["PagoProcesado", "El sistema cobro el viaje."],
    ["PedidoCalificado", "Cliente y conductor calificaron el viaje."],
    ["PedidoCerrado", "El pedido quedo terminado correctamente."]
  ]);

  const estadosAlternos = Object.freeze([
    ["PedidoSinConductor", "No hubo conductores disponibles para aceptar el pedido."],
    ["PedidoExpirado", "La busqueda se agoto antes de encontrar conductor."],
    ["PedidoCanceladoPorCliente", "El cliente cancelo el pedido."],
    ["PedidoCanceladoPorConductor", "El conductor cancelo antes de iniciar o continuar la recogida."],
    ["PedidoCanceladoPorNoShow", "El cliente no se presento en el punto de recogida."],
    ["PedidoEnRevision", "El pedido quedo en revision por un incidente reportado."],
    ["PagoFallido", "No se pudo procesar el pago del viaje."],
    ["RecalcularTarifa", "Marca el nuevo destino para recalcular la tarifa."],
    ["ReembolsoEnRevision", "Tu solicitud de reembolso fue enviada a revision."],
    ["CalculandoRuta", "Calculando ruta real por calles."],
    ["RutaNoDisponible", "No se encontro una ruta disponible por calles."]
  ]);

  const todosLosEstados = Object.freeze([
    ...estadosPrincipales,
    ...estadosAlternos
  ]);

  const estadosTerminales = Object.freeze([
    "PedidoCerrado",
    "PedidoSinConductor",
    "PedidoExpirado",
    "PedidoCanceladoPorCliente",
    "PedidoCanceladoPorConductor",
    "PedidoCanceladoPorNoShow",
    "PedidoEnRevision",
    "PagoFallido",
    "ReembolsoEnRevision"
  ]);

  const estadosRegresoDirecto = Object.freeze([
    "OrigenSeleccionado",
    "DestinoSeleccionado",
    "TarifaCalculada",
    "MetodoPagoSeleccionado",
    "PedidoConfirmado",
    "CalculandoRuta",
    "RutaNoDisponible",
    "RecalcularTarifa"
  ]);

  const estadosReinicioObligatorio = Object.freeze([
    "BuscandoConductor",
    "ConductorAsignado",
    "ConductorEnCamino",
    "ConductorLlego",
    "EsperandoCliente",
    "ClienteAbordo",
    "PedidoEnCurso",
    "LlegandoDestino",
    "DestinoAlcanzado",
    "PedidoFinalizado",
    "PagoProcesado",
    "PedidoCalificado",
    "PedidoCerrado",
    "PedidoSinConductor",
    "PedidoExpirado",
    "PedidoCanceladoPorCliente",
    "PedidoCanceladoPorConductor",
    "PedidoCanceladoPorNoShow",
    "PedidoEnRevision",
    "PagoFallido",
    "PagoRechazado",
    "ReembolsoEnRevision"
  ]);

  const nombresEstado = Object.freeze({
    ConductorLlego: "Conductor llego",
    ClienteAbordo: "Cliente abordo",
    CalculandoRuta: "Calculando ruta",
    PedidoSinConductor: "Pedido sin conductor",
    PedidoExpirado: "Pedido expirado",
    PedidoCanceladoPorCliente: "Pedido cancelado por cliente",
    PedidoCanceladoPorConductor: "Pedido cancelado por conductor",
    PedidoCanceladoPorNoShow: "Pedido cancelado por no-show",
    PedidoEnRevision: "Pedido en revision",
    PagoFallido: "Pago fallido",
    PagoRechazado: "Pago rechazado",
    RutaNoDisponible: "Ruta no disponible",
    RecalcularTarifa: "Recalcular tarifa",
    ReembolsoEnRevision: "Reembolso en revision"
  });

  const tiposViaje = RideTypeFactory.crearTipos({
    UberX: {
      nombre: "UberX",
      descripcion: "Viaje economico para hasta 4 personas",
      icono: "fa-car-side",
      base: 52,
      km: 8.8,
      min: 1.7
    },
    Comfort: {
      nombre: "Comfort",
      descripcion: "Autos mas amplios y conductores mejor calificados",
      icono: "fa-car-rear",
      base: 82,
      km: 12.6,
      min: 2.2
    },
    UberXL: {
      nombre: "UberXL",
      descripcion: "Mas espacio para hasta 6 personas",
      icono: "fa-van-shuttle",
      base: 112,
      km: 16.4,
      min: 3.1
    }
  });

  const metodosPago = MetodoPagoFactory.crearMetodos({
    "Tarjeta **** 4242": {
      tipo: "tarjeta",
      icono: "fa-credit-card"
    },
    Efectivo: {
      tipo: "efectivo",
      icono: "fa-money-bill-wave"
    },
    Wallet: {
      tipo: "wallet",
      icono: "fa-wallet"
    }
  });

  global.UberAppConfig = Object.freeze({
    estadosPrincipales,
    estadosAlternos,
    todosLosEstados,
    estadosTerminales,
    estadosRegresoDirecto,
    estadosReinicioObligatorio,
    nombresEstado,
    tiposViaje,
    metodosPago
  });
})(window);
