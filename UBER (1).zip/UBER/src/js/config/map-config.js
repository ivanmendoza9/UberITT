// Configuracion estatica del mapa, ruta inicial y flota simulada.
;(function (global) {
  "use strict";

  const centroMapa = Object.freeze([32.5007, -117.0301]);
  const origenInicial = Object.freeze([32.5147, -117.1135]);
  const destinoInicial = Object.freeze([32.5252, -117.0256]);

  const rutaInicial = Object.freeze([
    origenInicial,
    Object.freeze([32.5061, -117.1008]),
    Object.freeze([32.4948, -117.0852]),
    Object.freeze([32.4904, -117.0648]),
    Object.freeze([32.5056, -117.0505]),
    Object.freeze([32.5169, -117.0358]),
    destinoInicial
  ]);

  const rutasFlota = Object.freeze([
    Object.freeze([
      Object.freeze([32.5228, -117.1202]),
      Object.freeze([32.5164, -117.1088]),
      Object.freeze([32.5101, -117.0956]),
      Object.freeze([32.5188, -117.0822])
    ]),
    Object.freeze([
      Object.freeze([32.5432, -117.0645]),
      Object.freeze([32.5338, -117.0466]),
      Object.freeze([32.5202, -117.0351]),
      Object.freeze([32.5074, -117.0472])
    ]),
    Object.freeze([
      Object.freeze([32.4855, -117.0754]),
      Object.freeze([32.4936, -117.0602]),
      Object.freeze([32.5051, -117.0506]),
      Object.freeze([32.5161, -117.0415])
    ]),
    Object.freeze([
      Object.freeze([32.5351, -117.1021]),
      Object.freeze([32.5268, -117.0874]),
      Object.freeze([32.5193, -117.0739]),
      Object.freeze([32.5122, -117.0596])
    ]),
    Object.freeze([
      Object.freeze([32.4988, -117.1182]),
      Object.freeze([32.5055, -117.1057]),
      Object.freeze([32.5139, -117.0923]),
      Object.freeze([32.5231, -117.0804])
    ]),
    Object.freeze([
      Object.freeze([32.4706, -117.0424]),
      Object.freeze([32.4835, -117.0361]),
      Object.freeze([32.4971, -117.0307]),
      Object.freeze([32.5108, -117.0258])
    ])
  ]);

  global.UberMapConfig = Object.freeze({
    centroMapa,
    origenInicial,
    destinoInicial,
    rutaInicial,
    rutasFlota
  });
})(window);
