// Referencias DOM usadas por la app.
;(function (global) {
  "use strict";

  global.UberDomElements = Object.freeze({
    estadoTitulo: document.getElementById("estadoTitulo"),
    estadoDescripcion: document.getElementById("estadoDescripcion"),
    progressBar: document.getElementById("progressBar"),
    precioMapa: document.getElementById("precioMapa"),
    resumenRuta: document.getElementById("resumenRuta"),
    inputOrigen: document.getElementById("origen"),
    inputDestino: document.getElementById("destino"),
    paymentDropdown: document.getElementById("paymentDropdown"),
    selectedPaymentText: document.getElementById("selectedPaymentText"),
    fareOptions: document.getElementById("fareOptions"),
    fareRouteText: document.getElementById("fareRouteText"),
    paymentDecisionModal: document.getElementById("paymentDecisionModal"),
    paymentDecisionText: document.getElementById("paymentDecisionText"),
    ratingModal: document.getElementById("ratingModal"),
    ratingStars: document.getElementById("ratingStars"),
    ratingError: document.getElementById("ratingError"),
    originModeBtn: document.getElementById("originModeBtn"),
    destinationModeBtn: document.getElementById("destinationModeBtn"),
    estadoPaso: document.getElementById("estadoPaso"),
    stateOptions: document.getElementById("stateOptions"),
    backStateBtn: document.getElementById("backStateBtn"),
    cancelEventBtn: document.getElementById("cancelEventBtn"),
    changeDestinationEventBtn: document.getElementById("changeDestinationEventBtn"),
    emergencyEventBtn: document.getElementById("emergencyEventBtn"),
    refundEventBtn: document.getElementById("refundEventBtn"),
    mapSection: document.querySelector(".map-section")
  });
})(window);
