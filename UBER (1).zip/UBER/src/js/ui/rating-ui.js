// UI de calificacion: modal, estrellas y envio de rating.
;(function (global) {
  "use strict";

  function createRatingUi({
    ratingModal,
    ratingStars,
    ratingError,
    estadosPrincipales,
    getCalificacionCliente,
    setCalificacionCliente,
    setCalificacionEnviada,
    cambiarEstado,
    setFlujoActivo,
    setIndiceFlujo
  }) {
    function abrirModalCalificacion() {
      setCalificacionCliente(0);
      setCalificacionEnviada(false);
      actualizarEstrellasCalificacion();
      ratingError?.classList.remove("visible");
      ratingModal?.classList.add("open");
      ratingModal?.setAttribute("aria-hidden", "false");
    }

    function cerrarModalCalificacion() {
      ratingModal?.classList.remove("open");
      ratingModal?.setAttribute("aria-hidden", "true");
    }

    function seleccionarCalificacion(valor) {
      setCalificacionCliente(valor);
      ratingError?.classList.remove("visible");
      actualizarEstrellasCalificacion();
    }

    function actualizarEstrellasCalificacion() {
      if (!ratingStars) return;

      const calificacionCliente = getCalificacionCliente();

      ratingStars.querySelectorAll("button").forEach((boton, index) => {
        boton.classList.toggle("active", index < calificacionCliente);
      });
    }

    function enviarCalificacion() {
      const calificacionCliente = getCalificacionCliente();

      if (calificacionCliente < 1) {
        ratingError?.classList.add("visible");
        return;
      }

      setCalificacionEnviada(true);
      cerrarModalCalificacion();
      cambiarEstado(
        "PedidoCalificado",
        `Calificaste el viaje con ${calificacionCliente} estrella${calificacionCliente === 1 ? "" : "s"}.`
      );

      setTimeout(() => {
        cambiarEstado(
          "PedidoCerrado",
          "El pedido quedo terminado correctamente."
        );
        setFlujoActivo(false);
        setIndiceFlujo(estadosPrincipales.length);
      }, 900);
    }

    return Object.freeze({
      abrirModalCalificacion,
      cerrarModalCalificacion,
      seleccionarCalificacion,
      actualizarEstrellasCalificacion,
      enviarCalificacion
    });
  }

  global.UberAppUi = Object.assign(global.UberAppUi || {}, {
    createRatingUi
  });
})(window);
