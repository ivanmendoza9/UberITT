// UI de botones de eventos: habilita/deshabilita acciones segun Command.
;(function (global) {
  "use strict";

  function createEventButtonsUi({
    cancelEventBtn,
    changeDestinationEventBtn,
    emergencyEventBtn,
    refundEventBtn,
    getComando
  }) {
    function actualizarBotonesEventos() {
      configurarBotonEvento(
        cancelEventBtn,
        getComando("cancelar")?.puedeEjecutar(),
        getComando("cancelar")?.motivoNoDisponible || ""
      );
      configurarBotonEvento(
        changeDestinationEventBtn,
        getComando("cambiarDestino")?.puedeEjecutar(),
        getComando("cambiarDestino")?.motivoNoDisponible || ""
      );
      configurarBotonEvento(
        emergencyEventBtn,
        getComando("emergencia")?.puedeEjecutar(),
        getComando("emergencia")?.motivoNoDisponible || ""
      );
      configurarBotonEvento(
        refundEventBtn,
        getComando("reembolso")?.puedeEjecutar(),
        getComando("reembolso")?.motivoNoDisponible || ""
      );
    }

    function configurarBotonEvento(boton, disponible, motivo) {
      if (!boton) return;

      boton.disabled = !disponible;
      boton.title = disponible ? "" : motivo;
      boton.setAttribute("aria-disabled", String(!disponible));
    }

    return Object.freeze({
      actualizarBotonesEventos,
      configurarBotonEvento
    });
  }

  global.UberAppUi = Object.assign(global.UberAppUi || {}, {
    createEventButtonsUi
  });
})(window);
