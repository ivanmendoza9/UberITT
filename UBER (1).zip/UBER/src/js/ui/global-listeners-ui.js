// Listeners globales del UI: foco de inputs, escape, clicks externos y resize del mapa.
;(function (global) {
  "use strict";

  function registerGlobalListeners({
    inputOrigen,
    inputDestino,
    paymentDropdown,
    ratingModal,
    seleccionarModoMapa,
    cerrarMetodoPago,
    cerrarModalCalificacion,
    seleccionarCalificacion,
    invalidateMapSize
  }) {
    inputOrigen.addEventListener("focus", () => seleccionarModoMapa("origen"));
    inputDestino.addEventListener("focus", () => seleccionarModoMapa("destino"));

    window.addEventListener("load", () => {
      setTimeout(invalidateMapSize, 120);
    });

    document.addEventListener("click", event => {
      if (!paymentDropdown || paymentDropdown.contains(event.target)) return;

      cerrarMetodoPago();
    });

    document.addEventListener("keydown", event => {
      if (event.key === "Escape") {
        cerrarMetodoPago();
        if (ratingModal?.classList.contains("open")) {
          cerrarModalCalificacion();
        }
        return;
      }

      if (ratingModal?.classList.contains("open")) {
        const numero = Number(event.key);
        if (numero >= 1 && numero <= 5) seleccionarCalificacion(numero);
      }
    });
  }

  global.UberAppUi = Object.assign(global.UberAppUi || {}, {
    registerGlobalListeners
  });
})(window);
