// UI del mapa: Leaflet, marcadores, capa de ruta y modo origen/destino.
;(function (global) {
  "use strict";

  function createMapUi({
    L,
    LeafletMapAdapter,
    centroMapa,
    origenCoords,
    destinoCoords,
    rutaInicial,
    originModeBtn,
    destinationModeBtn,
    mapSection,
    inputOrigen,
    inputDestino,
    formatearCoordenadas
  }) {
    const map = L.map("map", {
      zoomControl: false
    }).setView(centroMapa, 12);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "&copy; OpenStreetMap"
    }).addTo(map);

    L.control.zoom({
      position: "bottomright"
    }).addTo(map);

    const origenIcon = L.divIcon({
      className: "custom-marker",
      html: `<div class="map-pin"><i class="fa-solid fa-location-dot" aria-hidden="true"></i></div>`,
      iconSize: [34, 34],
      iconAnchor: [17, 17]
    });

    const destinoIcon = L.divIcon({
      className: "custom-marker",
      html: `<div class="map-pin destination"><i class="fa-solid fa-flag-checkered" aria-hidden="true"></i></div>`,
      iconSize: [34, 34],
      iconAnchor: [17, 17]
    });

    const marcadorOrigen = L.marker(origenCoords, {
      icon: origenIcon,
      draggable: true
    })
      .addTo(map)
      .bindPopup("<b>Punto de partida</b><br>Real del Mar");

    const marcadorDestino = L.marker(destinoCoords, {
      icon: destinoIcon,
      draggable: true
    })
      .addTo(map)
      .bindPopup("<b>Destino</b><br>Zona Rio");

    const rutaLayer = L.polyline(rutaInicial, {
      color: "#000",
      weight: 6,
      opacity: 0.9,
      lineCap: "round",
      lineJoin: "round"
    }).addTo(map);

    const mapAdapter = new LeafletMapAdapter(map, rutaLayer);

    function seleccionarModoMapa(tipo) {
      originModeBtn.classList.toggle("active", tipo === "origen");
      destinationModeBtn.classList.toggle("active", tipo === "destino");
      mapSection.classList.add("picking");

      return tipo;
    }

    function actualizarPuntoVisual(tipo, coords) {
      if (tipo === "origen") {
        marcadorOrigen
          .setLatLng(coords)
          .setPopupContent(`<b>Punto de partida</b><br>${formatearCoordenadas(coords)}`);
        inputOrigen.value = `Origen: ${formatearCoordenadas(coords)}`;
        return;
      }

      marcadorDestino
        .setLatLng(coords)
        .setPopupContent(`<b>Destino</b><br>${formatearCoordenadas(coords)}`);
      inputDestino.value = `Destino: ${formatearCoordenadas(coords)}`;
    }

    function registrarEventosMapa({
      onMapClick,
      onOriginDragStart,
      onOriginDragEnd,
      onDestinationDragStart,
      onDestinationDragEnd
    }) {
      map.on("click", onMapClick);
      marcadorOrigen.on("dragstart", onOriginDragStart);
      marcadorOrigen.on("dragend", onOriginDragEnd);
      marcadorDestino.on("dragstart", onDestinationDragStart);
      marcadorDestino.on("dragend", onDestinationDragEnd);
    }

    function invalidateSize() {
      map.invalidateSize();
    }

    return Object.freeze({
      getMap: () => map,
      getMapAdapter: () => mapAdapter,
      seleccionarModoMapa,
      actualizarPuntoVisual,
      registrarEventosMapa,
      invalidateSize
    });
  }

  global.UberAppUi = Object.assign(global.UberAppUi || {}, {
    createMapUi
  });
})(window);
