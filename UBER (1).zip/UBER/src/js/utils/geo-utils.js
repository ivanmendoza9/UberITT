// Utilidades puras para calculos y formateo geoespacial.
;(function (global) {
  "use strict";

  function limitarProgreso(progreso) {
    return Math.min(1, Math.max(0, progreso));
  }

  function suavizarMovimiento(valor) {
    return valor < 0.5
      ? 2 * valor * valor
      : 1 - Math.pow(-2 * valor + 2, 2) / 2;
  }

  function normalizarLatLng(latlng) {
    if (Array.isArray(latlng)) {
      return latlng;
    }

    return [latlng.lat, latlng.lng];
  }

  function formatearCoordenadas(coords) {
    return `${coords[0].toFixed(5)}, ${coords[1].toFixed(5)}`;
  }

  function calcularDistanciaKm(origen, destino) {
    const radioTierraKm = 6371;
    const lat1 = gradosARadianes(origen[0]);
    const lat2 = gradosARadianes(destino[0]);
    const deltaLat = gradosARadianes(destino[0] - origen[0]);
    const deltaLng = gradosARadianes(destino[1] - origen[1]);
    const a =
      Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
      Math.cos(lat1) * Math.cos(lat2) *
      Math.sin(deltaLng / 2) * Math.sin(deltaLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return radioTierraKm * c;
  }

  function gradosARadianes(grados) {
    return grados * Math.PI / 180;
  }

  global.UberUtils = Object.freeze({
    limitarProgreso,
    suavizarMovimiento,
    normalizarLatLng,
    formatearCoordenadas,
    calcularDistanciaKm,
    gradosARadianes
  });
})(window);
