// Command Pattern
// Convierte acciones del usuario en objetos ejecutables y validables.
;(function (global) {
  "use strict";

  class RideCommand {
    constructor({
      puedeEjecutar,
      ejecutar,
      motivoNoDisponible,
      alNoDisponible = () => {}
    }) {
      this._puedeEjecutar = puedeEjecutar;
      this._ejecutar = ejecutar;
      this.motivoNoDisponible = motivoNoDisponible;
      this.alNoDisponible = alNoDisponible;
    }

    puedeEjecutar() {
      return this._puedeEjecutar();
    }

    ejecutar() {
      if (!this.puedeEjecutar()) {
        this.alNoDisponible();
        return false;
      }

      this._ejecutar();
      return true;
    }
  }

  global.UberPatterns = Object.assign(global.UberPatterns || {}, {
    RideCommand
  });
})(window);
