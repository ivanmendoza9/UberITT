// Observer Pattern
// Permite que varias partes de la UI reaccionen cuando cambia el estado.
;(function (global) {
  "use strict";

  class Subject {
    constructor() {
      this.observers = new Set();
    }

    subscribe(observer) {
      this.observers.add(observer);
      return () => this.observers.delete(observer);
    }

    notify(payload) {
      this.observers.forEach(observer => observer.update(payload));
    }
  }

  class EstadoUiObserver {
    constructor({ estadoTitulo, estadoDescripcion, formatearEstado }) {
      this.estadoTitulo = estadoTitulo;
      this.estadoDescripcion = estadoDescripcion;
      this.formatearEstado = formatearEstado;
    }

    update({ estado, descripcion }) {
      this.estadoTitulo.textContent = this.formatearEstado(estado);
      this.estadoDescripcion.textContent = descripcion;
    }
  }

  class EstadoProgresoObserver {
    constructor({ progressBar }) {
      this.progressBar = progressBar;
    }

    update({ progreso }) {
      if (progreso !== null) {
        this.progressBar.style.width = `${progreso}%`;
      }
    }
  }

  class EstadoFlujoObserver {
    constructor({ obtenerIndiceEstado, setIndiceFlujo }) {
      this.obtenerIndiceEstado = obtenerIndiceEstado;
      this.setIndiceFlujo = setIndiceFlujo;
    }

    update({ estado }) {
      const indiceEstado = this.obtenerIndiceEstado(estado);

      if (indiceEstado !== -1) {
        this.setIndiceFlujo(indiceEstado);
      }
    }
  }

  class EstadoAccionesObserver {
    constructor({ renderizarOpcionesEstado }) {
      this.renderizarOpcionesEstado = renderizarOpcionesEstado;
    }

    update() {
      this.renderizarOpcionesEstado();
    }
  }

  global.UberPatterns = Object.assign(global.UberPatterns || {}, {
    Subject,
    EstadoUiObserver,
    EstadoProgresoObserver,
    EstadoFlujoObserver,
    EstadoAccionesObserver
  });
})(window);
