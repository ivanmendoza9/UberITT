// Factory Pattern
// Centraliza la creacion de tipos de viaje, metodos de pago y conductores.
;(function (global) {
  "use strict";

  const {
    TarifaPorRutaStrategy,
    PagoStrategy,
    PagoTarjetaStrategy,
    PagoEfectivoStrategy,
    PagoWalletStrategy
  } = global.UberPatterns;

  class RideTypeFactory {
    static crearTipos(definiciones) {
      const tipos = Object.entries(definiciones).map(([id, definicion]) => [
        id,
        Object.freeze({
          id,
          ...definicion,
          tarifaStrategy: new TarifaPorRutaStrategy(definicion)
        })
      ]);

      return Object.freeze(Object.fromEntries(tipos));
    }
  }

  class MetodoPagoFactory {
    static crearMetodos(definiciones) {
      const estrategias = {
        tarjeta: PagoTarjetaStrategy,
        efectivo: PagoEfectivoStrategy,
        wallet: PagoWalletStrategy
      };

      return Object.freeze(Object.fromEntries(
        Object.entries(definiciones).map(([nombre, definicion]) => {
          const Strategy = estrategias[definicion.tipo] || PagoStrategy;

          return [
            nombre,
            Object.freeze({
              nombre,
              ...definicion,
              strategy: new Strategy(nombre)
            })
          ];
        })
      ));
    }
  }

  class DriverFactory {
    static crear({ id, nombre, ruta, marker, progreso, velocidad }) {
      return {
        id,
        nombre,
        ruta,
        marker,
        progreso,
        velocidad,
        asignado: false,
        distanciaAlOrigen: Infinity
      };
    }
  }

  global.UberPatterns = Object.assign(global.UberPatterns || {}, {
    RideTypeFactory,
    MetodoPagoFactory,
    DriverFactory
  });
})(window);
