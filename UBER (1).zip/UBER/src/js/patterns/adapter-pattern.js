// Adapter Pattern
// Aisla llamadas concretas de Leaflet para que la app dependa de una interfaz simple.
;(function (global) {
  "use strict";

  class LeafletMapAdapter {
    constructor(leafletMap, routeLayer) {
      this.map = leafletMap;
      this.routeLayer = routeLayer;
    }

    setRoute(coords) {
      this.routeLayer.setLatLngs(coords);
    }

    fitRoute(padding = [84, 84]) {
      this.map.fitBounds(this.routeLayer.getBounds(), { padding });
    }

    toLayerPoint(coords) {
      return this.map.latLngToLayerPoint(coords);
    }

    fromLayerPoint(point) {
      return this.map.layerPointToLatLng(point);
    }
  }

  global.UberPatterns = Object.assign(global.UberPatterns || {}, {
    LeafletMapAdapter
  });
})(window);
