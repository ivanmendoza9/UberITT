// state-pattern.js
// Implementacion independiente del patron State para el flujo de viaje.
"use strict";

class State {
  constructor(context) {
    this.context = context;
  }

  enter() {}

  handle() {}

  exit() {}
}

class RideContext {
  constructor() {
    this.state = null;
    this.history = [];
  }

  setState(stateInstance) {
    if (this.state && typeof this.state.exit === "function") {
      this.state.exit();
    }

    if (this.state) {
      this.history.push(this.state.constructor.name);
    }

    this.state = stateInstance;

    if (this.state && typeof this.state.enter === "function") {
      this.state.enter();
    }
  }

  handle() {
    if (!this.state) return;
    return this.state.handle();
  }
}

class PedidoIniciadoState extends State {
  enter() {
    console.log("Estado: Pedido iniciado");
  }

  handle() {
    console.log("Preparando solicitud de viaje...");
    this.context.setState(new OrigenSeleccionadoState(this.context));
  }
}

class OrigenSeleccionadoState extends State {
  enter() {
    console.log("Estado: Origen seleccionado");
  }

  handle() {
    console.log("Esperando destino...");
    this.context.setState(new DestinoSeleccionadoState(this.context));
  }
}

class DestinoSeleccionadoState extends State {
  enter() {
    console.log("Estado: Destino seleccionado");
  }

  handle() {
    console.log("Calculando tarifa...");
    this.context.setState(new TarifaCalculadaState(this.context));
  }
}

class TarifaCalculadaState extends State {
  enter() {
    console.log("Estado: Tarifa calculada");
  }

  handle() {
    console.log("Esperando metodo de pago...");
    this.context.setState(new MetodoPagoSeleccionadoState(this.context));
  }
}

class MetodoPagoSeleccionadoState extends State {
  enter() {
    console.log("Estado: Metodo de pago seleccionado");
  }

  handle() {
    console.log("Confirmando pedido...");
    this.context.setState(new PedidoConfirmadoState(this.context));
  }
}

class PedidoConfirmadoState extends State {
  enter() {
    console.log("Estado: Pedido confirmado");
  }

  handle() {
    console.log("Buscando conductor...");
    this.context.setState(new BuscandoConductorState(this.context));
  }
}

class BuscandoConductorState extends State {
  enter() {
    console.log("Estado: Buscando conductor");
  }

  handle() {
    console.log("Asignando conductor...");
    this.context.setState(new ConductorAsignadoState(this.context));
  }
}

class ConductorAsignadoState extends State {
  enter() {
    console.log("Estado: Conductor asignado");
  }

  handle() {
    console.log("Conductor en camino");
    this.context.setState(new ConductorEnCaminoState(this.context));
  }
}

class ConductorEnCaminoState extends State {
  enter() {
    console.log("Estado: Conductor en camino al origen");
  }

  handle() {
    console.log("Conductor llego al origen");
    this.context.setState(new ConductorLlegoState(this.context));
  }
}

class ConductorLlegoState extends State {
  enter() {
    console.log("Estado: Conductor llego");
  }

  handle() {
    console.log("Esperando cliente");
    this.context.setState(new EsperandoClienteState(this.context));
  }
}

class EsperandoClienteState extends State {
  enter() {
    console.log("Estado: Esperando cliente");
  }

  handle() {
    console.log("Cliente abordo");
    this.context.setState(new ClienteAbordoState(this.context));
  }
}

class ClienteAbordoState extends State {
  enter() {
    console.log("Estado: Cliente abordo");
  }

  handle() {
    console.log("Pedido en curso");
    this.context.setState(new PedidoEnCursoState(this.context));
  }
}

class PedidoEnCursoState extends State {
  enter() {
    console.log("Estado: Pedido en curso");
  }

  handle() {
    console.log("Llegando a destino");
    this.context.setState(new LlegandoDestinoState(this.context));
  }
}

class LlegandoDestinoState extends State {
  enter() {
    console.log("Estado: Llegando a destino");
  }

  handle() {
    console.log("Destino alcanzado");
    this.context.setState(new DestinoAlcanzadoState(this.context));
  }
}

class DestinoAlcanzadoState extends State {
  enter() {
    console.log("Estado: Destino alcanzado");
  }

  handle() {
    console.log("Finalizando pedido");
    this.context.setState(new PedidoFinalizadoState(this.context));
  }
}

class PedidoFinalizadoState extends State {
  enter() {
    console.log("Estado: Pedido finalizado");
  }

  handle() {
    console.log("Procesando pago");
    this.context.setState(new PagoProcesadoState(this.context));
  }
}

class PagoProcesadoState extends State {
  enter() {
    console.log("Estado: Pago procesado");
  }

  handle() {
    console.log("Solicitando calificacion");
    this.context.setState(new PedidoCalificadoState(this.context));
  }
}

class PedidoCalificadoState extends State {
  enter() {
    console.log("Estado: Pedido calificado");
  }

  handle() {
    console.log("Cerrando pedido");
    this.context.setState(new PedidoCerradoState(this.context));
  }
}

class PedidoCerradoState extends State {
  enter() {
    console.log("Estado: Pedido cerrado");
  }

  handle() {
    console.log("Flujo terminado");
  }
}

class PedidoSinConductorState extends State {
  enter() {
    console.log("Estado: Pedido sin conductor");
  }
}

class PedidoExpiradoState extends State {
  enter() {
    console.log("Estado: Pedido expirado");
  }
}

class PedidoCanceladoPorClienteState extends State {
  enter() {
    console.log("Estado: Pedido cancelado por cliente");
  }
}

class PedidoCanceladoPorConductorState extends State {
  enter() {
    console.log("Estado: Pedido cancelado por conductor");
  }
}

class PedidoCanceladoPorNoShowState extends State {
  enter() {
    console.log("Estado: Pedido cancelado por no-show");
  }
}

class PedidoEnRevisionState extends State {
  enter() {
    console.log("Estado: Pedido en revision");
  }
}

class PagoFallidoState extends State {
  enter() {
    console.log("Estado: Pago fallido");
  }
}

window.RideStatePattern = Object.freeze({
  RideContext,
  State,
  PedidoIniciadoState,
  OrigenSeleccionadoState,
  DestinoSeleccionadoState,
  TarifaCalculadaState,
  MetodoPagoSeleccionadoState,
  PedidoConfirmadoState,
  BuscandoConductorState,
  ConductorAsignadoState,
  ConductorEnCaminoState,
  ConductorLlegoState,
  EsperandoClienteState,
  ClienteAbordoState,
  PedidoEnCursoState,
  LlegandoDestinoState,
  DestinoAlcanzadoState,
  PedidoFinalizadoState,
  PagoProcesadoState,
  PedidoCalificadoState,
  PedidoCerradoState,
  PedidoSinConductorState,
  PedidoExpiradoState,
  PedidoCanceladoPorClienteState,
  PedidoCanceladoPorConductorState,
  PedidoCanceladoPorNoShowState,
  PedidoEnRevisionState,
  PagoFallidoState
});

window.UberPatterns = Object.assign(window.UberPatterns || {}, {
  StatePattern: window.RideStatePattern
});
