// Expone los handlers que usa el HTML con onclick inline.
;(function (global) {
  "use strict";

  const publicHandlerNames = Object.freeze([
    "iniciarFlujo",
    "limpiarCampo",
    "seleccionarModoMapa",
    "toggleMetodoPago",
    "seleccionarMetodoPago",
    "decidirProcesarPago",
    "reintentarProcesarPago",
    "solicitarCancelacion",
    "solicitarCambioDestino",
    "solicitarEmergencia",
    "solicitarReembolso",
    "regresarEstado",
    "abrirModalCalificacion",
    "enviarCalificacion",
    "seleccionarCalificacion",
    "abrirModalProcesarPago"
  ]);

  function exposePublicApi(api) {
    publicHandlerNames.forEach(nombre => {
      if (typeof api[nombre] === "function") {
        global[nombre] = api[nombre];
      }
    });

    if (global.UberPatterns) {
      global.UberPatterns = Object.freeze(global.UberPatterns);
    }
  }

  global.UberAppRuntime = Object.assign(global.UberAppRuntime || {}, {
    exposePublicApi
  });
})(window);
