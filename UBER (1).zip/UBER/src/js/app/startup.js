// Arranque inicial de mapa, flota y listeners de la app.
;(function (global) {
  "use strict";

  function startRideApp({
    crearFlotaCarros,
    mapAdapter,
    iniciarMovimientoFlota,
    seleccionarModoMapa,
    actualizarPreciosPorRuta,
    renderizarOpcionesEstado,
    actualizarRutaReal,
    mapUi,
    actualizarPuntoMapa,
    getModoMapa,
    registerGlobalListeners,
    inputOrigen,
    inputDestino,
    paymentDropdown,
    ratingModal,
    cerrarMetodoPago,
    cerrarModalCalificacion,
    seleccionarCalificacion
  }) {
    const flotaCarros = crearFlotaCarros();

    mapAdapter.fitRoute([80, 80]);
    iniciarMovimientoFlota(flotaCarros);
    seleccionarModoMapa("origen");
    actualizarPreciosPorRuta();
    renderizarOpcionesEstado();
    actualizarRutaReal({ actualizarEstado: false }).finally(renderizarOpcionesEstado);

    mapUi.registrarEventosMapa({
      onMapClick: event => actualizarPuntoMapa(getModoMapa(), event.latlng),
      onOriginDragStart: () => seleccionarModoMapa("origen"),
      onOriginDragEnd: event => actualizarPuntoMapa("origen", event.target.getLatLng(), { cambiarModo: false }),
      onDestinationDragStart: () => seleccionarModoMapa("destino"),
      onDestinationDragEnd: event => actualizarPuntoMapa("destino", event.target.getLatLng(), { cambiarModo: false })
    });

    registerGlobalListeners({
      inputOrigen,
      inputDestino,
      paymentDropdown,
      ratingModal,
      seleccionarModoMapa,
      cerrarMetodoPago,
      cerrarModalCalificacion,
      seleccionarCalificacion,
      invalidateMapSize: () => mapUi.invalidateSize()
    });

    return flotaCarros;
  }

  global.UberAppRuntime = Object.assign(global.UberAppRuntime || {}, {
    startRideApp
  });
})(window);
