// Facade de acciones para estado, flujo, comandos y eventos del viaje.
;(function (global) {
  "use strict";

  function createRideActions({
    getStateObserverService,
    getRideCommandService,
    getStateService,
    getRideFlowService,
    getRideEventService,
    getEventButtonsUi,
    getStatePanelUi
  }) {
    function ejecutarComandoEvento(nombre) {
      return getRideCommandService()?.ejecutarComandoEvento(nombre) || false;
    }

    return Object.freeze({
      registrarObservadoresEstado: () => getStateObserverService()?.registrarObservadoresEstado(),
      registrarComandosEvento: () => getRideCommandService()?.registrarComandosEvento(),
      ejecutarComandoEvento,
      mostrarEstado: (estado, descripcion, progreso = null, opciones = {}) => getStateService()?.mostrarEstado(estado, descripcion, progreso, opciones),
      cambiarEstado: (estado, descripcion, opciones = {}) => getStateService()?.cambiarEstado(estado, descripcion, opciones),
      formatearEstado: texto => getStateService()?.formatearEstado(texto) || texto,
      obtenerDescripcionEstado: (estado, descripcion) => getStateService()?.obtenerDescripcionEstado(estado, descripcion) || descripcion,
      iniciarFlujo: () => getRideFlowService()?.iniciarFlujo(),
      detenerFlujo: () => getRideFlowService()?.detenerFlujo(),
      avanzarEstadoManual: () => getRideFlowService()?.avanzarEstadoManual(),
      moverCarroPorEstado: estado => getRideFlowService()?.moverCarroPorEstado(estado),
      puedeCancelarCliente: () => getRideEventService()?.puedeCancelarCliente() || false,
      puedeCambiarDestino: () => getRideEventService()?.puedeCambiarDestino() || false,
      puedeReportarEmergencia: () => getRideEventService()?.puedeReportarEmergencia() || false,
      puedeSolicitarReembolso: () => getRideEventService()?.puedeSolicitarReembolso() || false,
      puedeMarcarSinConductor: () => getRideEventService()?.puedeMarcarSinConductor() || false,
      puedeExpirarPedido: () => getRideEventService()?.puedeExpirarPedido() || false,
      puedeCancelarPorConductor: () => getRideEventService()?.puedeCancelarPorConductor() || false,
      puedeMarcarNoShow: () => getRideEventService()?.puedeMarcarNoShow() || false,
      solicitarCancelacion: () => ejecutarComandoEvento("cancelar"),
      solicitarCambioDestino: () => ejecutarComandoEvento("cambiarDestino"),
      solicitarEmergencia: () => ejecutarComandoEvento("emergencia"),
      solicitarReembolso: () => ejecutarComandoEvento("reembolso"),
      cancelarCliente: () => getRideEventService()?.cancelarCliente(),
      cambiarDestino: () => getRideEventService()?.cambiarDestino(),
      emergencia: () => getRideEventService()?.emergencia(),
      reembolso: () => getRideEventService()?.reembolso(),
      marcarPedidoSinConductor: () => getRideEventService()?.marcarPedidoSinConductor(),
      expirarPedido: () => getRideEventService()?.expirarPedido(),
      cancelarPorConductor: () => getRideEventService()?.cancelarPorConductor(),
      marcarNoShow: () => getRideEventService()?.marcarNoShow(),
      actualizarBotonesEventos: () => getEventButtonsUi()?.actualizarBotonesEventos(),
      configurarBotonEvento: (boton, disponible, motivo) => getEventButtonsUi()?.configurarBotonEvento(boton, disponible, motivo),
      obtenerIndiceEstado: estado => getStateService()?.obtenerIndiceEstado(estado) ?? -1,
      obtenerPoliticaRegreso: () => getStateService()?.obtenerPoliticaRegreso() || "bloqueado",
      puedeRegresarEstado: () => getStateService()?.puedeRegresarEstado() || false,
      renderizarOpcionesEstado: () => getStatePanelUi()?.renderizarOpcionesEstado(),
      obtenerAccionesEstado: indiceEstado => getStatePanelUi()?.obtenerAccionesEstado(indiceEstado) || [],
      regresarEstado: () => getStateService()?.regresarEstado()
    });
  }

  global.UberAppRuntime = Object.assign(global.UberAppRuntime || {}, {
    createRideActions
  });
})(window);
