// Facade de acciones para servicios ya inicializados.
;(function (global) {
  "use strict";

  function createServiceActions({
    getDriverService,
    getMapInteractionService,
    getRouteService,
    getVehicleAnimationService,
    getFlotaCarros
  }) {
    return Object.freeze({
      crearFlotaCarros: () => getDriverService()?.crearFlotaCarros() || [],
      crearIconoCarro: asignado => getDriverService()?.crearIconoCarro(asignado),
      iniciarMovimientoFlota: flota => getDriverService()?.iniciarMovimientoFlota(flota || getFlotaCarros()),
      asignarConductorMasCercano: () => getDriverService()?.asignarConductorMasCercano(getFlotaCarros()) || null,
      anunciarConductor: conductor => getDriverService()?.anunciarConductor(conductor),
      liberarConductorAsignado: () => getDriverService()?.liberarConductorAsignado(),
      seleccionarModoMapa: tipo => getMapInteractionService()?.seleccionarModoMapa(tipo),
      actualizarPuntoMapa: (tipo, latlng, opciones = {}) => getMapInteractionService()?.actualizarPuntoMapa(tipo, latlng, opciones),
      limpiarCampo: id => getMapInteractionService()?.limpiarCampo(id),
      actualizarRutaReal: opciones => getRouteService()?.actualizarRutaReal(opciones),
      aplicarRutaDirectaTemporal: () => getRouteService()?.aplicarRutaDirectaTemporal(),
      moverCarro: coords => getVehicleAnimationService()?.moverCarro(coords),
      moverCarroAPunto: (coordsDestino, opciones = {}) => getVehicleAnimationService()?.moverCarroAPunto(coordsDestino, opciones),
      moverCarroEnRuta: (progresoDestino, opciones = {}) => getVehicleAnimationService()?.moverCarroEnRuta(progresoDestino, opciones),
      detenerAnimacionCarro: () => getVehicleAnimationService()?.detenerAnimacionCarro(),
      obtenerPuntoRuta: progreso => getVehicleAnimationService()?.obtenerPuntoRuta(progreso),
      obtenerPuntoEnCoordenadas: (coordenadas, progreso) => getVehicleAnimationService()?.obtenerPuntoEnCoordenadas(coordenadas, progreso),
      calcularLongitudRuta: () => getVehicleAnimationService()?.calcularLongitudRuta() || 0,
      calcularLongitudCoordenadas: coordenadas => getVehicleAnimationService()?.calcularLongitudCoordenadas(coordenadas) || 0
    });
  }

  global.UberAppRuntime = Object.assign(global.UberAppRuntime || {}, {
    createServiceActions
  });
})(window);
