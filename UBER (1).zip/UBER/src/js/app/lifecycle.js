// Limpieza de timers y animaciones del runtime.
;(function (global) {
  "use strict";

  function registerLifecycleCleanup({
    getAnimacionFlotaId,
    getAnimacionCarroId,
    detenerIntervalo
  }) {
    global.addEventListener("beforeunload", () => {
      if (typeof global.cancelAnimationFrame === "function") {
        const animacionFlotaId = getAnimacionFlotaId?.();
        const animacionCarroId = getAnimacionCarroId?.();

        if (animacionFlotaId) global.cancelAnimationFrame(animacionFlotaId);
        if (animacionCarroId) global.cancelAnimationFrame(animacionCarroId);
      }

      detenerIntervalo?.();
    });
  }

  global.UberAppRuntime = Object.assign(global.UberAppRuntime || {}, {
    registerLifecycleCleanup
  });
})(window);
