// Facade de acciones para modulos UI ya inicializados.
;(function (global) {
  "use strict";

  function createUiActions({
    getPaymentUi,
    getRatingUi,
    getFareUi,
    getTipoViajeSeleccionado
  }) {
    return Object.freeze({
      toggleMetodoPago: event => getPaymentUi()?.toggleMetodoPago(event),
      cerrarMetodoPago: () => getPaymentUi()?.cerrarMetodoPago(),
      seleccionarMetodoPago: (nombre, icono, event) => getPaymentUi()?.seleccionarMetodoPago(nombre, icono, event),
      abrirModalProcesarPago: () => getPaymentUi()?.abrirModalProcesarPago(),
      cerrarModalProcesarPago: () => getPaymentUi()?.cerrarModalProcesarPago(),
      decidirProcesarPago: procesar => getPaymentUi()?.decidirProcesarPago(procesar),
      reintentarProcesarPago: () => getPaymentUi()?.reintentarProcesarPago(),
      abrirModalCalificacion: () => getRatingUi()?.abrirModalCalificacion(),
      cerrarModalCalificacion: () => getRatingUi()?.cerrarModalCalificacion(),
      seleccionarCalificacion: valor => getRatingUi()?.seleccionarCalificacion(valor),
      actualizarEstrellasCalificacion: () => getRatingUi()?.actualizarEstrellasCalificacion(),
      enviarCalificacion: () => getRatingUi()?.enviarCalificacion(),
      renderizarOpcionesTarifa: () => getFareUi()?.renderizarOpcionesTarifa(),
      seleccionarTipoViaje: tipoId => getFareUi()?.seleccionarTipoViaje(tipoId),
      actualizarPreciosPorRuta: () => getFareUi()?.actualizarPreciosPorRuta(),
      calcularRangoPrecio: (tipoId = getTipoViajeSeleccionado()) => getFareUi()?.calcularRangoPrecio(tipoId) || "",
      calcularPrecioFinal: (tipoId = getTipoViajeSeleccionado()) => getFareUi()?.calcularPrecioFinal(tipoId) || "",
      actualizarResumenRuta: () => getFareUi()?.actualizarResumenRuta()
    });
  }

  global.UberAppRuntime = Object.assign(global.UberAppRuntime || {}, {
    createUiActions
  });
})(window);
