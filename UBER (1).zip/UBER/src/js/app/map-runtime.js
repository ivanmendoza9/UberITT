// Construye el runtime del mapa y los servicios que dependen de Leaflet.
;(function (global) {
  "use strict";

  function createMapRuntime({
    createMapUi,
    createMapInteractionService,
    createVehicleAnimationService,
    createRouteService,
    createDriverService,
    L,
    LeafletMapAdapter,
    DriverFactory,
    centroMapa,
    origenCoords,
    destinoCoords,
    rutaInicial,
    rutasFlota,
    originModeBtn,
    destinationModeBtn,
    mapSection,
    inputOrigen,
    inputDestino,
    formatearCoordenadas,
    normalizarLatLng,
    progressBar,
    limitarProgreso,
    suavizarMovimiento,
    calcularDistanciaKm,
    estadoDescripcion,
    getModoMapa,
    setModoMapa,
    getFlujoActivo,
    setIndiceFlujo,
    getRecalculoDestinoEnCurso,
    setRecalculoDestinoEnCurso,
    setOrigenCoords,
    setDestinoCoords,
    detenerFlujo,
    actualizarRutaReal,
    getRutaPorCallesDisponible,
    cambiarEstado,
    getCarMarker,
    getAnimacionCarroId,
    setAnimacionCarroId,
    getProgresoCarro,
    setProgresoCarro,
    getRutaCoords,
    getOrigenCoords,
    getDestinoCoords,
    getConductorAsignado,
    setRutaCalculando,
    setRutaPorCallesDisponible,
    setRutaCoords,
    setRutaInfo,
    moverCarroEnRuta,
    actualizarResumenRuta,
    actualizarPreciosPorRuta,
    mostrarEstado,
    obtenerDescripcionEstado,
    obtenerPuntoEnCoordenadas,
    setConductorAsignado,
    setCarMarker,
    setAnimacionFlotaId
  }) {
    const mapUi = createMapUi({
      L,
      LeafletMapAdapter,
      centroMapa,
      origenCoords,
      destinoCoords,
      rutaInicial,
      originModeBtn,
      destinationModeBtn,
      mapSection,
      inputOrigen,
      inputDestino,
      formatearCoordenadas
    });
    const map = mapUi.getMap();
    const mapAdapter = mapUi.getMapAdapter();

    const mapInteractionService = createMapInteractionService({
      mapUi,
      normalizarLatLng,
      progressBar,
      inputOrigen,
      inputDestino,
      getModoMapa,
      setModoMapa,
      getFlujoActivo,
      setIndiceFlujo,
      getRecalculoDestinoEnCurso,
      setRecalculoDestinoEnCurso,
      setOrigenCoords,
      setDestinoCoords,
      detenerFlujo,
      actualizarRutaReal,
      getRutaPorCallesDisponible,
      cambiarEstado
    });

    const vehicleAnimationService = createVehicleAnimationService({
      L,
      mapAdapter,
      limitarProgreso,
      suavizarMovimiento,
      getCarMarker,
      getAnimacionCarroId,
      setAnimacionCarroId,
      getProgresoCarro,
      setProgresoCarro,
      getRutaCoords,
      getOrigenCoords
    });

    const routeService = createRouteService({
      mapAdapter,
      calcularDistanciaKm,
      getOrigenCoords,
      getDestinoCoords,
      getConductorAsignado,
      getFlujoActivo,
      setRutaCalculando,
      setRutaPorCallesDisponible,
      setRutaCoords,
      setRutaInfo,
      moverCarroEnRuta,
      actualizarResumenRuta,
      actualizarPreciosPorRuta,
      mostrarEstado,
      obtenerDescripcionEstado
    });

    const driverService = createDriverService({
      L,
      map,
      rutasFlota,
      DriverFactory,
      obtenerPuntoEnCoordenadas,
      getOrigenCoords,
      getConductorAsignado,
      setConductorAsignado,
      setCarMarker,
      setProgresoCarro,
      setAnimacionFlotaId,
      estadoDescripcion
    });

    return Object.freeze({
      mapUi,
      map,
      mapAdapter,
      mapInteractionService,
      vehicleAnimationService,
      routeService,
      driverService
    });
  }

  global.UberAppRuntime = Object.assign(global.UberAppRuntime || {}, {
    createMapRuntime
  });
})(window);
