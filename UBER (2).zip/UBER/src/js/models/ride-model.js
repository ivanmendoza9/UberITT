/**
 * MODEL: Ride Model
 * 
 * Almacena el estado de los datos del viaje.
 * - origen: punto de partida del viaje
 * - destino: punto final del viaje
 * - distancia: distancia calculada en km
 * - tarifa: precio del viaje
 * - tipoViaje: tipo de servicio (estándar, premium, etc)
 * - conductor: información del conductor asignado
 * - estado: estado actual del viaje (Inicial, EnProgreso, Completado, etc)
 */
export const rideModel = {
  origen: null,
  destino: null,
  distancia: 0,
  tarifa: 0,
  tipoViaje: null,
  conductor: null,
  estado: "Inicial"
};