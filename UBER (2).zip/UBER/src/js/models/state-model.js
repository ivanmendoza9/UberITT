/**
 * MODEL: State Model
 * 
 * Almacena el estado general de la aplicación.
 * - estadoActual: estado en el que se encuentra la aplicación
 *   (Inicial, OrigenSeleccionado, DestinoSeleccionado, ViajeAsignado, EnViaje, Completado, etc)
 */
export const stateModel = {
  estadoActual: "Inicial"
};