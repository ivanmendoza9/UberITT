/**
 * MODEL: Driver Model
 * 
 * Almacena el estado de los datos de conductores.
 * - conductores: array con lista de conductores disponibles
 * - conductorAsignado: información del conductor asignado al viaje actual
 */
export const driverModel = {
  conductores: [],
  conductorAsignado: null
};