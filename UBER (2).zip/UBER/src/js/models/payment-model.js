/**
 * MODEL: Payment Model
 * 
 * Almacena el estado de los datos del pago.
 * - metodoPago: método seleccionado (tarjeta, efectivo, billetera digital, etc)
 * - estadoPago: booleano que indica si el pago fue procesado correctamente
 */
export const paymentModel = {
  metodoPago: null,
  estadoPago: false
};