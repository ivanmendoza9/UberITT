// Pantalla inicial de bienvenida antes del panel principal.
;(function () {
  "use strict";

  const welcomeScreen = document.getElementById("welcomeScreen");
  const welcomeForm = document.getElementById("welcomeForm");
  const welcomeName = document.getElementById("welcomeName");
  const logoutBtn = document.getElementById("logoutBtn");
  const bookingTitle = document.querySelector(".booking-card h1");
  const SESSION_KEY = "viajeAppDemoSession";
  const NAME_KEY = "viajeAppDemoName";

  if (!welcomeScreen || !welcomeForm) return;

  function actualizarTitulo(nombre) {
    if (!bookingTitle) return;

    bookingTitle.textContent = nombre ? `Solicita un viaje, ${nombre}` : "Solicita un viaje";
  }

  function haySesionActiva() {
    return localStorage.getItem(SESSION_KEY) === "active";
  }

  function ocultarBienvenida() {
    welcomeScreen.classList.add("is-hidden");
    welcomeScreen.setAttribute("aria-hidden", "true");
    welcomeScreen.hidden = true;
    window.dispatchEvent(new Event("resize"));
  }

  function cerrarBienvenida() {
    const nombre = welcomeName?.value.trim();

    localStorage.setItem(SESSION_KEY, "active");
    localStorage.setItem(NAME_KEY, nombre || "");
    actualizarTitulo(nombre);

    welcomeScreen.classList.add("is-hidden");
    welcomeScreen.setAttribute("aria-hidden", "true");

    setTimeout(() => {
      welcomeScreen.hidden = true;
      window.dispatchEvent(new Event("resize"));
    }, 260);
  }

  function abrirBienvenida() {
    localStorage.removeItem(SESSION_KEY);
    localStorage.removeItem(NAME_KEY);
    actualizarTitulo("");

    if (welcomeName) {
      welcomeName.value = "";
    }

    welcomeScreen.hidden = false;
    welcomeScreen.setAttribute("aria-hidden", "false");

    requestAnimationFrame(() => {
      welcomeScreen.classList.remove("is-hidden");
      welcomeName?.focus();
    });
  }

  welcomeForm.addEventListener("submit", event => {
    event.preventDefault();
    cerrarBienvenida();
  });

  logoutBtn?.addEventListener("click", abrirBienvenida);

  //if (haySesionActiva()) {
  //  actualizarTitulo(localStorage.getItem(NAME_KEY) || "");
  //  ocultarBienvenida();
  //  return;
  //}

  welcomeName?.focus();
})();
