/**
 * MVC Pattern (Model-View-Controller)
 * 
 * El patrón MVC divide la aplicación en tres componentes interconectados:
 * 
 * 1. MODEL: Gestiona los datos y la lógica de negocio
 *    - Contiene el estado de la aplicación
 *    - Notifica a las vistas cuando los datos cambian
 * 
 * 2. VIEW: Presenta los datos al usuario
 *    - Muestra la información del modelo
 *    - Envía acciones del usuario al controlador
 * 
 * 3. CONTROLLER: Intermediario entre modelo y vista
 *    - Recibe eventos del usuario desde la vista
 *    - Actualiza el modelo según corresponda
 *    - Actualiza la vista con nuevos datos
 */

