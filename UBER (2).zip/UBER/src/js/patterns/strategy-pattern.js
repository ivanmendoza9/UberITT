// Strategy Pattern
// Encapsula algoritmos intercambiables para tarifas y pagos.

// Este archivo contiene las estrategias
// utilizadas para calcular tarifas.
//
// Cada clase representa un algoritmo diferente.
//
// El patrón Strategy permite encapsular
// distintos comportamientos y cambiarlos
// dinámicamente durante la ejecución.
//
// Ventaja:
// El sistema puede agregar nuevos métodos
// de cálculo sin afectar el resto del código.

;(function (global) {
  "use strict";

  function redondearCinco(valor) {
    return Math.max(35, Math.ceil(valor / 5) * 5);
  }

  class TarifaPorRutaStrategy {
    constructor({ base, km, min }) {
      this.base = base;
      this.km = km;
      this.min = min;
    }

    calcular({ distanciaKm, duracionMin }) {
      const estimado = this.base + distanciaKm * this.km + duracionMin * this.min;

      return {
        minimo: redondearCinco(estimado * 0.92),
        maximo: redondearCinco(estimado * 1.18)
      };
    }
  }

  class PagoStrategy {
    constructor(nombre) {
      this.nombre = nombre;
    }

    procesar({ confirmado, total }) {
      if (!confirmado) {
        return {
          aprobado: false,
          mensaje: "El pago no fue procesado. Puedes cambiar el metodo de pago e intentarlo otra vez."
        };
      }

      return {
        aprobado: true,
        mensaje: `Pago procesado correctamente por ${total} con ${this.nombre}.`
      };
    }
  }

  class PagoTarjetaStrategy extends PagoStrategy {}
  class PagoEfectivoStrategy extends PagoStrategy {}
  class PagoWalletStrategy extends PagoStrategy {}

  global.UberPatterns = Object.assign(global.UberPatterns || {}, {
    TarifaPorRutaStrategy,
    PagoStrategy,
    PagoTarjetaStrategy,
    PagoEfectivoStrategy,
    PagoWalletStrategy
  });
})(window);
