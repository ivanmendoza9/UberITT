// Nueva estrategia de pago
//class PayPalStrategy {
 //ProcesarPago(cantidad) {
//   return `Pago de MXN ${cantidad} procesado con PayPal`;
// }
//}
