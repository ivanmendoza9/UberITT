/**
 * CONTROLLER: Ride Controller
 * 
 * Coordina la lógica del viaje y el flujo entre el modelo y la vista.
 * Maneja acciones como:
 * - Iniciar y finalizar viajes
 * - Calcular distancias y tarifas
 * - Actualizar el estado del viaje
 * - Asignar conductores
 */

import { rideModel } from "../models/ride-model.js";

export function iniciarViaje() {
  console.log("Viaje iniciado");
}

export function finalizarViaje() {
  console.log("Viaje finalizado");
}