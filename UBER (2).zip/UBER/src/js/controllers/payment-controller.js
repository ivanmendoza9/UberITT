/**
 * CONTROLLER: Payment Controller
 * 
 * Coordina la lógica de pagos y el flujo entre el modelo y la vista.
 * Maneja acciones como:
 * - Seleccionar método de pago
 * - Procesar pagos
 * - Validar transacciones
 * - Generar recibos
 */

import { paymentModel } from "../models/payment-model.js";

export function seleccionarMetodoPago(metodo) {
  paymentModel.metodoPago = metodo;
}