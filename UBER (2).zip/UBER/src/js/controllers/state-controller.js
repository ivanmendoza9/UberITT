/**
 * CONTROLLER: State Controller
 * 
 * Coordina la lógica del estado general de la aplicación.
 * Maneja acciones como:
 * - Cambiar el estado de la aplicación
 * - Notificar a observadores cuando cambia el estado
 * - Validar transiciones de estado válidas
 * - Sincronizar estado entre diferentes partes de la aplicación
 */

import { stateModel } from "../models/state-model.js";

export function cambiarEstado(nuevoEstado) {
  stateModel.estadoActual = nuevoEstado;
}