/**
 * VIEW: State View
 * 
 * Presenta el estado actual de la aplicación al usuario.
 * Responsabilidades:
 * - Mostrar el paso actual del viaje
 * - Mostrar mensajes y descripciones de estado
 * - Mostrar acciones disponibles en cada estado
 * - Actualizar automáticamente cuando cambia el estado (patrón Observer)
 * - Mostrar información del viaje (origin, destino, precio, conductor, etc)
 */
// UI del panel de estados: paso actual, acciones disponibles y mensaje vacio.

// El patrón Observer actualiza automáticamente
// la interfaz cuando cambia el estado del viaje.
//
// Gracias a esto, la UI se sincroniza
// sin necesidad de actualizar manualmente
// cada componente.

;(function (global) {
  "use strict";

  function createStatePanelUi({
    estadoPaso,
    stateOptions,
    backStateBtn,
    estadosPrincipales,
    estadosAlternos = [],
    getEstadoActual,
    getHistorialEstadosLength,
    getRutaCalculando,
    getFlujoActivo,
    getRutaPorCallesDisponible,
    getPagoProcesadoConfirmado,
    getCalificacionEnviada,
    obtenerIndiceEstado,
    obtenerPoliticaRegreso,
    puedeRegresarEstado,
    actualizarBotonesEventos,
    abrirModalProcesarPago,
    reintentarProcesarPago,
    abrirModalCalificacion,
    avanzarEstadoManual,
    marcarPedidoSinConductor,
    expirarPedido,
    cancelarPorConductor,
    marcarNoShow
  }) {
    const estadosAlternosSet = new Set(estadosAlternos.map(([nombre]) => nombre));

    function renderizarOpcionesEstado() {
      if (!estadoPaso || !stateOptions || !backStateBtn) return;

      const indiceEstado = obtenerIndiceEstado(getEstadoActual());
      estadoPaso.textContent = indiceEstado === -1
        ? (estadosAlternosSet.has(getEstadoActual()) ? "Estado alterno" : "Estado personalizado")
        : `Estado ${indiceEstado + 1} de ${estadosPrincipales.length}`;

      const politicaRegreso = obtenerPoliticaRegreso();
      const backStateLabel = backStateBtn.querySelector("span");
      const backStateIcon = backStateBtn.querySelector("i");

      backStateBtn.disabled = !puedeRegresarEstado();
      backStateBtn.title = obtenerTextoAyudaRegreso(politicaRegreso);

      if (backStateLabel) {
        backStateLabel.textContent = politicaRegreso === "reiniciar" ? "Reiniciar" : "Regresar";
      }

      if (backStateIcon) {
        backStateIcon.className = politicaRegreso === "reiniciar"
          ? "fa-solid fa-rotate-left"
          : "fa-solid fa-arrow-left";
      }

      actualizarBotonesEventos();
      stateOptions.innerHTML = "";

      const acciones = obtenerAccionesEstado(indiceEstado);

      if (!acciones.length) {
        const mensaje = document.createElement("p");
        mensaje.className = "state-empty";
        mensaje.textContent = getRutaCalculando()
          ? "Calculando la ruta..."
          : "Selecciona origen o destino y haz clic en el mapa.";
        stateOptions.appendChild(mensaje);
        return;
      }

      acciones.forEach(accion => {
        const boton = document.createElement("button");
        boton.type = "button";
        boton.className = `state-option-btn ${accion.variante || ""}`.trim();
        boton.textContent = accion.texto;
        boton.addEventListener("click", accion.ejecutar);
        stateOptions.appendChild(boton);
      });
    }

    function obtenerTextoAyudaRegreso(politicaRegreso) {
      if (politicaRegreso === "reiniciar") {
        return "Este estado no puede volver al paso anterior; reinicia el pedido.";
      }

      if (politicaRegreso === "anterior") {
        return getHistorialEstadosLength() > 0
          ? "Volver al paso anterior."
          : "No hay un paso anterior disponible.";
      }

      return "No se puede regresar desde este estado.";
    }

    function obtenerAccionesEstado(indiceEstado) {
      const acciones = [];
      const estadoActual = getEstadoActual();

      if (estadoActual === "PagoProcesado" && !getPagoProcesadoConfirmado()) {
        acciones.push({
          texto: "Decidir pago",
          variante: "primary",
          ejecutar: abrirModalProcesarPago
        });
        return acciones;
      }

      if (estadoActual === "PagoRechazado") {
        acciones.push({
          texto: "Intentar pago",
          variante: "primary",
          ejecutar: reintentarProcesarPago
        });
        return acciones;
      }

      if (estadoActual === "PagoFallido") {
        acciones.push({
          texto: "Intentar pago",
          variante: "primary",
          ejecutar: reintentarProcesarPago
        });
        return acciones;
      }

      if (estadoActual === "PedidoCalificado" && !getCalificacionEnviada()) {
        acciones.push({
          texto: "Calificar viaje",
          variante: "primary",
          ejecutar: abrirModalCalificacion
        });
        return acciones;
      }

      if (!getFlujoActivo() && getRutaPorCallesDisponible() && indiceEstado !== -1 && indiceEstado < estadosPrincipales.length - 1) {
        acciones.push({
          texto: "Avanzar estado",
          variante: "primary",
          ejecutar: avanzarEstadoManual
        });
      }

      if (estadoActual === "BuscandoConductor") {
        acciones.push({
          texto: "Sin conductor",
          ejecutar: marcarPedidoSinConductor
        });
        acciones.push({
          texto: "Expirar busqueda",
          ejecutar: expirarPedido
        });
      }

      if ([
        "ConductorAsignado",
        "ConductorEnCamino",
        "ConductorLlego",
        "EsperandoCliente"
      ].includes(estadoActual)) {
        acciones.push({
          texto: "Conductor cancela",
          variante: "danger",
          ejecutar: cancelarPorConductor
        });
      }

      if (estadoActual === "EsperandoCliente") {
        acciones.push({
          texto: "No-show",
          variante: "danger",
          ejecutar: marcarNoShow
        });
      }

      return acciones;
    }

    return Object.freeze({
      renderizarOpcionesEstado,
      obtenerAccionesEstado
    });
  }

  global.UberAppUi = Object.assign(global.UberAppUi || {}, {
    createStatePanelUi
  });
})(window);
