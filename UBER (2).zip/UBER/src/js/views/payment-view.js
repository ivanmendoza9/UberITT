/**
 * VIEW: Payment View
 * 
 * Presenta la interfaz de pagos al usuario.
 * Responsabilidades:
 * - Mostrar dropdown con métodos de pago disponibles
 * - Mostrar el precio del viaje
 * - Mostrar modal de confirmación de pago
 * - Capturar selección de método de pago
 * - Capturar confirmación o cancelación del pago
 * - Actualizar la interfaz según el estado del pago
 */
// UI de pagos: dropdown, seleccion de metodo y modal de procesamiento.
;(function (global) {
  "use strict";

  function createPaymentUi({
    paymentDropdown,
    selectedPaymentText,
    paymentDecisionModal,
    paymentDecisionText,
    precioMapa,
    metodosPago,
    PagoStrategy,
    getMetodoPagoSeleccionado,
    setMetodoPagoSeleccionado,
    getEstadoActual,
    getPagoProcesadoConfirmado,
    setPagoProcesadoConfirmado,
    estadoDescripcion,
    obtenerDescripcionEstado,
    detenerFlujo,
    cambiarEstado,
    abrirModalCalificacion,
    calcularPrecioFinal
  }) {
    let totalPagoActual = "";

    function obtenerTotalPago() {
      totalPagoActual = calcularPrecioFinal?.() || precioMapa.textContent;
      return totalPagoActual;
    }

    function actualizarTextoDecisionPago() {
      if (!paymentDecisionText) return;

      paymentDecisionText.textContent = `Deseas procesar ${obtenerTotalPago()} con ${getMetodoPagoSeleccionado()}?`;
    }

    function toggleMetodoPago(event) {
      event?.stopPropagation();

      if (!paymentDropdown) return;

      const abierto = paymentDropdown.classList.toggle("open");
      const trigger = paymentDropdown.querySelector(".payment-trigger");
      trigger?.setAttribute("aria-expanded", String(abierto));
    }

    function cerrarMetodoPago() {
      if (!paymentDropdown) return;

      paymentDropdown.classList.remove("open");
      paymentDropdown
        .querySelector(".payment-trigger")
        ?.setAttribute("aria-expanded", "false");
    }

    function seleccionarMetodoPago(nombre, icono, event) {
      event?.stopPropagation();

      const metodo = metodosPago[nombre] || {
        nombre,
        icono,
        strategy: new PagoStrategy(nombre)
      };

      setMetodoPagoSeleccionado(metodo.nombre);

      if (selectedPaymentText) {
        selectedPaymentText.textContent = metodo.nombre;
      }

      const iconoActual = paymentDropdown?.querySelector(".payment-left > i");

      if (iconoActual) {
        iconoActual.className = `fa-solid ${metodo.icono}`;
      }

      document.querySelectorAll(".payment-option").forEach(opcion => {
        opcion.classList.toggle("active", opcion.textContent.trim() === metodo.nombre);
      });

      if (getEstadoActual() === "MetodoPagoSeleccionado") {
        estadoDescripcion.textContent = obtenerDescripcionEstado(
          "MetodoPagoSeleccionado",
          ""
        );
      }

      if (getEstadoActual() === "PagoProcesado" && !getPagoProcesadoConfirmado()) {
        estadoDescripcion.textContent = obtenerDescripcionEstado("PagoProcesado", "");
        actualizarTextoDecisionPago();
      }

      cerrarMetodoPago();
    }

    function obtenerMetodoPagoActual() {
      const metodoPagoSeleccionado = getMetodoPagoSeleccionado();

      return metodosPago[metodoPagoSeleccionado] || {
        nombre: metodoPagoSeleccionado,
        icono: "fa-credit-card",
        strategy: new PagoStrategy(metodoPagoSeleccionado)
      };
    }

    function abrirModalProcesarPago() {
      setPagoProcesadoConfirmado(false);
      actualizarTextoDecisionPago();

      paymentDecisionModal?.classList.add("open");
      paymentDecisionModal?.setAttribute("aria-hidden", "false");
    }

    function cerrarModalProcesarPago() {
      paymentDecisionModal?.classList.remove("open");
      paymentDecisionModal?.setAttribute("aria-hidden", "true");
    }

    function decidirProcesarPago(procesar) {
      cerrarModalProcesarPago();
      const resultadoPago = obtenerMetodoPagoActual().strategy.procesar({
        confirmado: procesar,
        total: totalPagoActual || obtenerTotalPago()
      });

      if (!resultadoPago.aprobado) {
        setPagoProcesadoConfirmado(false);
        detenerFlujo();
        cambiarEstado(
          "PagoFallido",
          resultadoPago.mensaje
        );
        return;
      }

      setPagoProcesadoConfirmado(true);
      cambiarEstado(
        "PagoProcesado",
        resultadoPago.mensaje
      );

      setTimeout(() => {
        cambiarEstado(
          "PedidoCalificado",
          obtenerDescripcionEstado("PedidoCalificado", "")
        );
        abrirModalCalificacion();
      }, 900);
    }

    function reintentarProcesarPago() {
      cambiarEstado(
        "PagoProcesado",
        obtenerDescripcionEstado("PagoProcesado", "")
      );
      abrirModalProcesarPago();
    }

    return Object.freeze({
      toggleMetodoPago,
      cerrarMetodoPago,
      seleccionarMetodoPago,
      obtenerMetodoPagoActual,
      abrirModalProcesarPago,
      cerrarModalProcesarPago,
      decidirProcesarPago,
      reintentarProcesarPago
    });
  }

  global.UberAppUi = Object.assign(global.UberAppUi || {}, {
    createPaymentUi
  });
})(window);
