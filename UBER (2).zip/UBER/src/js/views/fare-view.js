// UI de tarifas: tipos de viaje, precios estimados y resumen de ruta.

// Aquí se implementa el patrón Strategy.
//
// Cada tipo de viaje (UberX, Comfort y UberXL)
// tiene una estrategia diferente para calcular tarifas.
//
// El sistema cambia dinámicamente el algoritmo
// dependiendo del servicio seleccionado.
//
// Esto permite:
// - cambiar cálculos sin modificar el sistema principal
// - reducir acoplamiento
// - agregar nuevos tipos de tarifa fácilmente
//
// Ejemplo:
// UberX calcula una tarifa básica,
// mientras UberXL utiliza una tarifa más alta.
//
// La estrategia se ejecuta mediante:
//
// tipo.tarifaStrategy.calcular(...)

;(function (global) {
  "use strict";

  function createFareUi({
    fareOptions,
    fareRouteText,
    precioMapa,
    resumenRuta,
    tiposViaje,
    estadoDescripcion,
    getRutaInfo,
    getTipoViajeSeleccionado,
    setTipoViajeSeleccionado,
    getEstadoActual
  }) {
    function calcularDetallePrecio(tipoId = getTipoViajeSeleccionado()) {
      const tipo = tiposViaje[tipoId] || tiposViaje.UberX;
      const { minimo, maximo } = tipo.tarifaStrategy.calcular(getRutaInfo());
      const total = Math.round((minimo + maximo) / 2);

      return { minimo, maximo, total };
    }

    function calcularRangoPrecio(tipoId = getTipoViajeSeleccionado()) {
      const { minimo, maximo } = calcularDetallePrecio(tipoId);

      return `MXN ${minimo}-${maximo}`;
    }

    function calcularPrecioFinal(tipoId = getTipoViajeSeleccionado()) {
      return `MXN ${calcularDetallePrecio(tipoId).total}`;
    }

    function renderizarOpcionesTarifa() {
      if (!fareOptions) return;

      const rutaInfo = getRutaInfo();

      fareRouteText.innerHTML = `
        <strong>${rutaInfo.distanciaKm.toFixed(1)} km</strong> - 
        <strong>${Math.max(1, Math.round(rutaInfo.duracionMin))} min estimados</strong>
      `;

      fareOptions.innerHTML = "";

      Object.entries(tiposViaje).forEach(([id, tipo]) => {
        const boton = document.createElement("button");
        boton.type = "button";
        boton.className = `fare-option ${id === getTipoViajeSeleccionado() ? "active" : ""}`.trim();
        boton.onclick = () => seleccionarTipoViaje(id);
        boton.innerHTML = `
          <span class="fare-option-icon">
            <i class="fa-solid ${tipo.icono}" aria-hidden="true"></i>
          </span>
          <span>
            <strong>${tipo.nombre}</strong>
            <small>${tipo.descripcion}</small>
          </span>
          <span class="fare-option-price">${calcularRangoPrecio(id)}</span>
        `;
        fareOptions.appendChild(boton);
      });
    }

    function seleccionarTipoViaje(tipoId) {
      if (!tiposViaje[tipoId]) return;

      setTipoViajeSeleccionado(tipoId);

      // GUARDAR TIPO DE SERVICIO GLOBAL
      window.tipoServicioSeleccionado = tipoId;

      actualizarPreciosPorRuta();

      if (getEstadoActual() === "TarifaCalculada") {
        estadoDescripcion.textContent = 
          `${tiposViaje[tipoId].nombre} seleccionado por ${calcularRangoPrecio(tipoId)}.`;
      }
    }

    function actualizarPreciosPorRuta() {
      if (precioMapa) {
        precioMapa.textContent = calcularRangoPrecio(getTipoViajeSeleccionado());
      }

      renderizarOpcionesTarifa();
    }

    function actualizarResumenRuta() {
      if (!resumenRuta) return;

      const rutaInfo = getRutaInfo();
      const minutos = Math.max(1, Math.round(rutaInfo.duracionMin));
      const minimo = Math.max(1, Math.round(minutos * 0.9));
      const maximo = Math.max(minimo + 1, Math.round(minutos * 1.15));

      resumenRuta.innerHTML = `
        <strong>${rutaInfo.distanciaKm.toFixed(1)} km</strong> - 
        <strong>${minimo}-${maximo} min</strong>
      `;
    }

    return Object.freeze({
      renderizarOpcionesTarifa,
      seleccionarTipoViaje,
      actualizarPreciosPorRuta,
      calcularRangoPrecio,
      calcularPrecioFinal,
      actualizarResumenRuta
    });
  }

  global.UberAppUi = Object.assign(global.UberAppUi || {}, {
    createFareUi
  });
})(window);
